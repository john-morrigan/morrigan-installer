import sqlite3
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


@dataclass
class Event:
    trigger_utc: str
    io_utc: str
    utc_zone: str
    endpoint_id: str
    file_id: str
    action_type: str
    file_type: Optional[str]
    file_size: int
    action_source: Optional[str]
    target_source: Optional[str]
    hu_per: int = 0

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Event':
        return cls(**data)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class EventQueue:
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or Config.DATABASE_PATH
        self._lock = threading.Lock()
        self._ensure_database()

    def _ensure_database(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS event_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    trigger_utc TEXT NOT NULL,
                    io_utc TEXT NOT NULL,
                    utc_zone TEXT,
                    endpoint_id TEXT NOT NULL,
                    file_id TEXT NOT NULL,
                    action_type TEXT NOT NULL,
                    file_type TEXT,
                    file_size INTEGER NOT NULL,
                    action_source TEXT,
                    target_source TEXT,
                    hu_per INTEGER DEFAULT 0,
                    sent BOOLEAN DEFAULT FALSE
                )
            """)

            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_event_queue_created_at
                ON event_queue(created_at)
            """)

            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_event_queue_sent
                ON event_queue(sent)
            """)

            conn.commit()

        logger.debug(f"Database initialized at {self.db_path}")

    def add_event(self, event: Event) -> bool:
        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    conn.execute("""
                        INSERT INTO event_queue (
                            trigger_utc, io_utc, utc_zone, endpoint_id, file_id,
                            action_type, file_type, file_size, action_source,
                            target_source, hu_per
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        event.trigger_utc, event.io_utc, event.utc_zone,
                        event.endpoint_id, event.file_id, event.action_type,
                        event.file_type, event.file_size, event.action_source,
                        event.target_source, event.hu_per
                    ))
                    conn.commit()

                logger.debug(f"Added event to queue: {event.action_type}")

                return True

            except Exception as e:
                logger.error(f"Failed to add event to queue: {e}")
                return False

        try:
            self._enforce_size_limits()
        except Exception as e:
            logger.error(f"Failed to enforce size limits: {e}")

    def get_pending_events(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    conn.row_factory = sqlite3.Row
                    cursor = conn.cursor()

                    query = """
                        SELECT * FROM event_queue
                        WHERE sent = FALSE
                        ORDER BY created_at ASC
                    """

                    if limit:
                        query += f" LIMIT {limit}"

                    cursor.execute(query)
                    rows = cursor.fetchall()

                    events = []
                    for row in rows:
                        event_dict = dict(row)
                        events.append(event_dict)

                    logger.debug(f"Retrieved {len(events)} pending events")
                    return events

            except Exception as e:
                logger.error(f"Failed to get pending events: {e}")
                return []

    def mark_events_sent(self, event_ids: List[int]) -> bool:
        if not event_ids:
            return True

        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    placeholders = ','.join('?' * len(event_ids))
                    conn.execute(f"""
                        UPDATE event_queue
                        SET sent = TRUE
                        WHERE id IN ({placeholders})
                    """, event_ids)
                    conn.commit()

                logger.debug(f"Marked {len(event_ids)} events as sent")
                return True

            except Exception as e:
                logger.error(f"Failed to mark events as sent: {e}")
                return False

    def get_queue_stats(self) -> Dict[str, int]:
        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()

                    cursor.execute("SELECT COUNT(*) FROM event_queue")
                    total = cursor.fetchone()[0]

                    cursor.execute("SELECT COUNT(*) FROM event_queue WHERE sent = FALSE")
                    pending = cursor.fetchone()[0]

                    sent = total - pending

                    db_size = self.db_path.stat().st_size if self.db_path.exists() else 0

                    return {
                        'total_events': total,
                        'pending_events': pending,
                        'sent_events': sent,
                        'db_size_bytes': db_size
                    }

            except Exception as e:
                logger.error(f"Failed to get queue stats: {e}")
                return {}

    def _enforce_size_limits(self) -> None:
        try:
            stats = self.get_queue_stats()

            if stats.get('total_events', 0) > Config.MAX_QUEUE_SIZE:
                self._cleanup_old_events_by_count()

            size_mb = stats.get('db_size_bytes', 0) / (1024 * 1024)
            if size_mb > Config.MAX_QUEUE_SIZE_MB:
                self._cleanup_old_events_by_size()

        except Exception as e:
            logger.error(f"Failed to enforce size limits: {e}")

    def _cleanup_old_events_by_count(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    DELETE FROM event_queue
                    WHERE id NOT IN (
                        SELECT id FROM event_queue
                        ORDER BY created_at DESC
                        LIMIT ?
                    )
                """, (Config.MAX_QUEUE_SIZE,))

                deleted = conn.total_changes
                conn.commit()

                if deleted > 0:
                    logger.info(f"Cleaned up {deleted} old events due to count limit")

        except Exception as e:
            logger.error(f"Failed to cleanup events by count: {e}")

    def _cleanup_old_events_by_size(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    DELETE FROM event_queue
                    WHERE sent = TRUE
                    AND id IN (
                        SELECT id FROM event_queue
                        WHERE sent = TRUE
                        ORDER BY created_at ASC
                        LIMIT (
                            SELECT COUNT(*) / 4
                            FROM event_queue
                            WHERE sent = TRUE
                        )
                    )
                """)

                deleted = conn.total_changes
                conn.commit()

                if deleted > 0:
                    logger.info(f"Cleaned up {deleted} old events due to size limit")

        except Exception as e:
            logger.error(f"Failed to cleanup events by size: {e}")

    def clear_all_events(self) -> bool:
        with self._lock:
            try:
                with sqlite3.connect(self.db_path) as conn:
                    conn.execute("DELETE FROM event_queue")
                    conn.commit()

                logger.info("Cleared all events from queue")
                return True

            except Exception as e:
                logger.error(f"Failed to clear events: {e}")
                return False
