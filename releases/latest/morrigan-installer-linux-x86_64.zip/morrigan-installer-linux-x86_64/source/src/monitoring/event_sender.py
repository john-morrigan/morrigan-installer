import time
import threading
from typing import Dict, Any

from ..config import Config
from ..logger import get_logger
from ..storage.event_queue import EventQueue
from ..api.client import api_client

logger = get_logger(__name__)


class EventSender:
    def __init__(self, event_queue: EventQueue):
        self.event_queue = event_queue
        self.running = False
        self.thread = None
        self._stop_event = threading.Event()
        self.last_send_time = time.time()

    def start(self) -> None:
        if self.running:
            logger.warning("Event sender already running")
            return

        self.running = True
        self._stop_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()
        logger.info("Event sender started")

    def stop(self) -> None:
        if not self.running:
            return

        logger.info("Stopping event sender...")
        self.running = False
        self._stop_event.set()

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5)

        logger.info("Event sender stopped")

    def _run(self) -> None:
        logger.info("Event sender thread started")

        while self.running and not self._stop_event.is_set():
            try:
                if self._should_send_events():
                    self._send_pending_events()

                self._stop_event.wait(timeout=60)

            except Exception as e:
                logger.error(f"Error in event sender loop: {e}")
                self._stop_event.wait(timeout=30)

        logger.info("Event sender thread finished")

    def _should_send_events(self) -> bool:
        try:
            stats = self.event_queue.get_queue_stats()
            pending_count = stats.get('pending_events', 0)

            if pending_count >= Config.BATCH_SIZE:
                logger.info(f"Sending events due to count threshold: {pending_count} >= {Config.BATCH_SIZE}")
                return True

            time_since_last_send = time.time() - self.last_send_time
            if time_since_last_send >= Config.BATCH_TIMEOUT and pending_count > 0:
                logger.info(f"Sending events due to time threshold: {time_since_last_send:.0f}s >= {Config.BATCH_TIMEOUT}s")
                return True

            return False

        except Exception as e:
            logger.error(f"Error checking send conditions: {e}")
            return False

    def _send_pending_events(self) -> None:
        try:
            events = self.event_queue.get_pending_events(limit=Config.BATCH_SIZE)
            if not events:
                logger.debug("No pending events to send")
                return

            logger.info(f"Sending {len(events)} pending events")

            event_ids = [event['id'] for event in events]
            response = api_client.send_events_with_retry(events)

            if response.success:
                if self.event_queue.mark_events_sent(event_ids):
                    logger.info(f"Successfully sent and marked {len(events)} events")
                    self.last_send_time = time.time()
                else:
                    logger.error("Failed to mark events as sent after successful API call")
            else:
                logger.error(f"Failed to send events: {response.error}")

        except Exception as e:
            logger.error(f"Error sending pending events: {e}")

    def force_send(self) -> bool:
        try:
            logger.info("Force sending pending events")
            self._send_pending_events()
            return True
        except Exception as e:
            logger.error(f"Error in force send: {e}")
            return False

    def get_status(self) -> Dict[str, Any]:
        queue_stats = self.event_queue.get_queue_stats()

        return {
            'running': self.running,
            'last_send_time': self.last_send_time,
            'time_since_last_send': time.time() - self.last_send_time,
            'retry_attempts': api_client.retry_handler.attempt_count,
            'queue_stats': queue_stats
        }
