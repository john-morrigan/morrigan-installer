import platform
import time
import threading
import subprocess
from typing import Optional, Dict, Any
from urllib.parse import urlparse

from .base_monitor import BaseMonitor
from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


class WindowMonitor(BaseMonitor):
    def __init__(self, event_queue):
        super().__init__("WindowMonitor")
        self.event_queue = event_queue
        self.monitoring_thread = None
        self.stop_event = threading.Event()

        self.current_window = None
        self.current_url = None
        self.window_start_time = time.time()

        self.system = platform.system()
        self._setup_platform_tools()

    def _setup_platform_tools(self) -> None:
        self.tools_available = False

        if self.system == "Darwin":  # macOS
            self.tools_available = self._check_macos_tools()
        elif self.system == "Linux":
            self.tools_available = self._check_linux_tools()
        elif self.system == "Windows":
            self.tools_available = self._check_windows_tools()

        if not self.tools_available:
            logger.warning(f"Window monitoring tools not available on {self.system}")

    def _check_macos_tools(self) -> bool:
        try:
            from AppKit import NSWorkspace
            return True
        except ImportError:
            # Check if osascript is available
            try:
                subprocess.run(['osascript', '-e', 'tell application "System Events" to return'],
                             capture_output=True, timeout=2)
                return True
            except Exception:
                return False

    def _check_linux_tools(self) -> bool:
        """Check if Linux tools are available"""
        import shutil
        return (shutil.which('xdotool') is not None or
                shutil.which('wmctrl') is not None)

    def _check_windows_tools(self) -> bool:
        """Check if Windows tools are available"""
        try:
            import win32gui
            import psutil
            return True
        except ImportError:
            return False

    def start_monitoring(self) -> None:
        """Start window monitoring"""
        if self.running:
            logger.warning("Window monitor already running")
            return

        if not self.tools_available:
            logger.error("Window monitoring tools not available")
            return

        self.running = True
        self.stop_event.clear()
        self.monitoring_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitoring_thread.start()
        logger.info("Window monitoring started")

    def stop_monitoring(self) -> None:
        if not self.running:
            return

        self.running = False
        self.stop_event.set()

        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=2)

        logger.info("Window monitoring stopped")

    def _monitor_loop(self) -> None:
        """Main monitoring loop"""
        logger.debug("Window monitoring loop started")

        while not self.stop_event.wait(2.0):  # Check every 2 seconds
            try:
                self._check_window_change()
            except Exception as e:
                logger.error(f"Error in window monitor loop: {e}")

        logger.debug("Window monitoring loop ended")

    def _check_window_change(self) -> None:
        """Check for window/application changes"""
        try:
            current_app = self._get_current_application()
            current_title = self._get_current_window_title()
            current_url = self._get_current_browser_url()

            # Check if we switched to a different window/app
            window_changed = (current_app != self.current_window or
                            current_url != self.current_url)

            if window_changed:
                # Process the previous window session if it was significant
                if self.current_window and self._was_significant_session():
                    self._create_window_event()

                # Update current state
                self.current_window = current_app
                self.current_url = current_url
                self.window_start_time = time.time()

                logger.debug(f"Window changed to: {current_app} - {current_title}")

                # Check if new window is LLM domain
                if current_url and Config.is_llm_domain(current_url):
                    logger.info(f"Switched to LLM domain: {current_url}")

        except Exception as e:
            logger.error(f"Error checking window change: {e}")

    def _was_significant_session(self) -> bool:
        """Check if the previous window session was significant enough to record"""
        session_duration = time.time() - self.window_start_time

        # Consider significant if:
        # - Session lasted more than 30 seconds
        # - Was an LLM domain
        # - Was a productivity application

        if session_duration < 30:
            return False

        if self.current_url and Config.is_llm_domain(self.current_url):
            return True

        if self.current_window and self._is_productivity_app(self.current_window):
            return True

        return False

    def _is_productivity_app(self, app_name: str) -> bool:
        if not app_name:
            return False

        app_lower = app_name.lower()
        productivity_apps = [
            'code', 'visual studio', 'pycharm', 'intellij', 'eclipse',
            'word', 'excel', 'powerpoint', 'pages', 'numbers', 'keynote',
            'notion', 'obsidian', 'logseq', 'roam',
            'figma', 'sketch', 'adobe', 'canva'
        ]

        return any(prod_app in app_lower for prod_app in productivity_apps)

    def _create_window_event(self) -> None:
        """Create an event for the completed window session"""
        session_duration = time.time() - self.window_start_time

        is_llm_session = (self.current_url and Config.is_llm_domain(self.current_url))

        event = self.create_event(
            action_type="window_session",
            file_path=self.current_url or self.current_window,
            file_size=int(session_duration),  # Duration in seconds
            action_source=self.current_window,
            target_source=self.current_url or "desktop",
            hu_per=self._calculate_human_percentage_for_session(session_duration, is_llm_session)
        )

        self.event_queue.add_event(event)
        logger.info(f"Window session event: {self.current_window} - {session_duration:.1f}s - LLM: {is_llm_session}")

    def _calculate_human_percentage_for_session(self, duration: float, is_llm: bool) -> int:
        """Calculate human interaction percentage for window session"""
        human_indicators = 0
        total_indicators = 4

        if duration > 120:  # 2 minutes
            human_indicators += 1

        if 30 <= duration <= 300:  # 30 seconds to 5 minutes
            human_indicators += 1

        # LLM domains suggest human interaction
        if is_llm:
            human_indicators += 2

        if self._is_productivity_app(self.current_window or ""):
            human_indicators += 1

        return min(int((human_indicators / total_indicators) * 100), 100)

    def _get_current_application(self) -> Optional[str]:
        """Get current active application"""
        try:
            if self.system == "Darwin":
                return self._get_current_app_macos()
            elif self.system == "Linux":
                return self._get_current_app_linux()
            elif self.system == "Windows":
                return self._get_current_app_windows()
        except Exception as e:
            logger.debug(f"Could not get current application: {e}")
        return None

    def _get_current_window_title(self) -> Optional[str]:
        try:
            if self.system == "Darwin":
                return self._get_window_title_macos()
            elif self.system == "Linux":
                return self._get_window_title_linux()
            elif self.system == "Windows":
                return self._get_window_title_windows()
        except Exception as e:
            logger.debug(f"Could not get window title: {e}")
        return None

    def _get_current_browser_url(self) -> Optional[str]:
        """Get current browser URL if possible"""
        try:
            if self.system == "Darwin":
                return self._get_browser_url_macos()
        except Exception as e:
            logger.debug(f"Could not get browser URL: {e}")
        return None

    # macOS implementations
    def _get_current_app_macos(self) -> Optional[str]:
        """Get current application on macOS"""
        try:
            from AppKit import NSWorkspace
            workspace = NSWorkspace.sharedWorkspace()
            active_app = workspace.activeApplication()
            return active_app.get('NSApplicationName')
        except ImportError:
            # Fallback to AppleScript
            result = subprocess.run([
                'osascript', '-e',
                'tell application "System Events" to get name of first application process whose frontmost is true'
            ], capture_output=True, text=True, timeout=2)
            return result.stdout.strip() if result.returncode == 0 else None

    def _get_window_title_macos(self) -> Optional[str]:
        """Get window title on macOS"""
        try:
            result = subprocess.run([
                'osascript', '-e',
                'tell application "System Events" to get title of front window of first application process whose frontmost is true'
            ], capture_output=True, text=True, timeout=2)
            return result.stdout.strip() if result.returncode == 0 else None
        except Exception:
            return None

    def _get_browser_url_macos(self) -> Optional[str]:
        """Get browser URL on macOS"""
        # Try common browsers
        browsers = [
            ('Safari', 'tell application "Safari" to get URL of active tab of front window'),
            ('Google Chrome', 'tell application "Google Chrome" to get URL of active tab of front window'),
            ('Firefox', None)  # Firefox doesn't support AppleScript easily
        ]

        current_app = self._get_current_app_macos()
        for browser_name, script in browsers:
            if current_app and browser_name.lower() in current_app.lower() and script:
                try:
                    result = subprocess.run(['osascript', '-e', script],
                                          capture_output=True, text=True, timeout=2)
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except Exception:
                    continue
        return None

    def _get_current_app_linux(self) -> Optional[str]:
        """Get current application on Linux"""
        try:
            # Try xdotool
            result = subprocess.run(['xdotool', 'getactivewindow', 'getwindowpid'],
                                  capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                pid = int(result.stdout.strip())
                import psutil
                process = psutil.Process(pid)
                return process.name()
        except Exception:
            pass

        try:
            # Try wmctrl
            result = subprocess.run(['wmctrl', '-l'],
                                  capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                # This is simplified - would need more parsing
                return "linux-window"
        except Exception:
            pass

        return None

    def _get_window_title_linux(self) -> Optional[str]:
        """Get window title on Linux"""
        try:
            result = subprocess.run(['xdotool', 'getactivewindow', 'getwindowname'],
                                  capture_output=True, text=True, timeout=2)
            return result.stdout.strip() if result.returncode == 0 else None
        except Exception:
            return None

    # Windows implementations
    def _get_current_app_windows(self) -> Optional[str]:
        """Get current application on Windows"""
        try:
            import win32gui
            import win32process
            import psutil

            hwnd = win32gui.GetForegroundWindow()
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            process = psutil.Process(pid)
            return process.name()
        except Exception:
            return None

    def _get_window_title_windows(self) -> Optional[str]:
        try:
            import win32gui
            hwnd = win32gui.GetForegroundWindow()
            return win32gui.GetWindowText(hwnd)
        except Exception:
            return None
