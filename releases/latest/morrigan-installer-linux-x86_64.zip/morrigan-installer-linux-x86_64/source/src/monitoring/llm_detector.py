import re
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from urllib.parse import urlparse

from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


@dataclass
class ContextClue:
    type: str
    confidence: float
    description: str
    source: str


class LLMContextDetector:
    def __init__(self):
        self.interaction_history: List[Dict] = []
        self.max_history = 50

        self._compile_patterns()

    def _compile_patterns(self):
        self.ai_patterns = [
            re.compile(r'\bas an ai\b', re.IGNORECASE),
            re.compile(r'\bi cannot\b', re.IGNORECASE),
            re.compile(r'\bi apologize\b', re.IGNORECASE),
            re.compile(r'\bhere is\b', re.IGNORECASE),
            re.compile(r'\bbased on\b', re.IGNORECASE),
            re.compile(r'\bin conclusion\b', re.IGNORECASE),
            re.compile(r'\bfurthermore\b', re.IGNORECASE),
            re.compile(r'\bhowever\b', re.IGNORECASE),
        ]

        self.code_patterns = [
            re.compile(r'```[\w]*\n', re.MULTILINE),  # Code blocks
            re.compile(r'\bdef \w+\(', re.IGNORECASE),  # Function definitions
            re.compile(r'\bclass \w+', re.IGNORECASE),  # Class definitions
            re.compile(r'\bimport \w+', re.IGNORECASE),  # Import statements
            re.compile(r'\bfrom \w+ import', re.IGNORECASE),  # From imports
        ]

        self.prompt_patterns = [
            re.compile(r'\bwrite.*code\b', re.IGNORECASE),
            re.compile(r'\bcreate.*function\b', re.IGNORECASE),
            re.compile(r'\bgenerate.*\b', re.IGNORECASE),
            re.compile(r'\bexplain.*\b', re.IGNORECASE),
            re.compile(r'\bhelp.*with\b', re.IGNORECASE),
            re.compile(r'\bhow.*to\b', re.IGNORECASE),
            re.compile(r'\bwhat.*is\b', re.IGNORECASE),
            re.compile(r'\bcan you\b', re.IGNORECASE),
        ]

    def analyze_interaction(
        self,
        content: str,
        source_app: Optional[str] = None,
        source_url: Optional[str] = None,
        interaction_type: str = "clipboard"
    ) -> Tuple[bool, float, List[ContextClue]]:
        clues: List[ContextClue] = []

        if source_url:
            domain_clue = self._analyze_domain(source_url)
            if domain_clue:
                clues.append(domain_clue)

        content_clues = self._analyze_content(content)
        clues.extend(content_clues)

        timing_clue = self._analyze_timing_patterns(content, interaction_type)
        if timing_clue:
            clues.append(timing_clue)

        pattern_clues = self._analyze_interaction_patterns()
        clues.extend(pattern_clues)

        confidence = self._calculate_confidence(clues)
        is_llm = confidence > 0.6  # Threshold for LLM detection

        self._record_interaction(content, source_app, source_url, confidence, clues)

        logger.debug(f"LLM analysis: confidence={confidence:.2f}, clues={len(clues)}")

        return is_llm, confidence, clues

    def _analyze_domain(self, url: str) -> Optional[ContextClue]:
        if Config.is_llm_domain(url):
            parsed = urlparse(url)
            return ContextClue(
                type="domain",
                confidence=0.9,
                description=f"Known LLM domain: {parsed.netloc}",
                source="url_analysis"
            )
        return None

    def _analyze_content(self, content: str) -> List[ContextClue]:
        clues = []

        ai_matches = sum(1 for pattern in self.ai_patterns if pattern.search(content))
        if ai_matches > 0:
            clues.append(ContextClue(
                type="content",
                confidence=min(0.8, ai_matches * 0.3),
                description=f"Contains AI-specific language ({ai_matches} matches)",
                source="content_analysis"
            ))

        code_matches = sum(1 for pattern in self.code_patterns if pattern.search(content))
        if code_matches > 0:
            clues.append(ContextClue(
                type="content",
                confidence=min(0.7, code_matches * 0.2),
                description=f"Contains code patterns ({code_matches} matches)",
                source="content_analysis"
            ))

        prompt_matches = sum(1 for pattern in self.prompt_patterns if pattern.search(content))
        if prompt_matches > 0:
            clues.append(ContextClue(
                type="content",
                confidence=min(0.6, prompt_matches * 0.2),
                description=f"Contains prompt-like language ({prompt_matches} matches)",
                source="content_analysis"
            ))

        if len(content) > 1000 and content.count('\n') > 10:
            clues.append(ContextClue(
                type="content",
                confidence=0.5,
                description="Large, well-structured text",
                source="content_analysis"
            ))

        if re.search(r'\n\d+\.', content) or re.search(r'\nStep \d+', content, re.IGNORECASE):
            clues.append(ContextClue(
                type="content",
                confidence=0.4,
                description="Contains numbered steps or lists",
                source="content_analysis"
            ))

        return clues

    def _analyze_timing_patterns(
        self,
        content: str,
        interaction_type: str
    ) -> Optional[ContextClue]:
        if len(self.interaction_history) < 2:
            return None

        current_time = time.time()
        recent_interactions = [
            interaction for interaction in self.interaction_history[-5:]
            if current_time - interaction['timestamp'] < 300  # Last 5 minutes
        ]

        if len(recent_interactions) >= 2:
            types = [interaction.get('type', 'unknown') for interaction in recent_interactions]
            if self._is_alternating_pattern(types):
                return ContextClue(
                    type="timing",
                    confidence=0.6,
                    description="Alternating interaction pattern detected",
                    source="timing_analysis"
                )

        return None

    def _analyze_interaction_patterns(self) -> List[ContextClue]:
        clues = []

        if len(self.interaction_history) < 3:
            return clues

        recent_high_confidence = sum(
            1 for interaction in self.interaction_history[-10:]
            if interaction.get('confidence', 0) > 0.7
        )

        if recent_high_confidence >= 3:
            clues.append(ContextClue(
                type="pattern",
                confidence=0.5,
                description="Multiple high-confidence LLM interactions recently",
                source="pattern_analysis"
            ))

        return clues

    def _is_alternating_pattern(self, types: List[str]) -> bool:
        if len(types) < 3:
            return False

        for i in range(len(types) - 2):
            if types[i] == types[i + 2] and types[i] != types[i + 1]:
                return True

        return False

    def _calculate_confidence(self, clues: List[ContextClue]) -> float:
        if not clues:
            return 0.0

        type_weights = {
            'domain': 1.0,
            'content': 0.8,
            'timing': 0.6,
            'pattern': 0.4
        }

        weighted_sum = 0.0
        total_weight = 0.0

        for clue in clues:
            weight = type_weights.get(clue.type, 0.5)
            weighted_sum += clue.confidence * weight
            total_weight += weight

        if total_weight == 0:
            return 0.0

        base_confidence = weighted_sum / total_weight

        evidence_types = set(clue.type for clue in clues)
        type_bonus = (len(evidence_types) - 1) * 0.1

        return min(1.0, base_confidence + type_bonus)

    def _record_interaction(
        self,
        content: str,
        source_app: Optional[str],
        source_url: Optional[str],
        confidence: float,
        clues: List[ContextClue]
    ) -> None:
        interaction = {
            'timestamp': time.time(),
            'content_length': len(content),
            'source_app': source_app,
            'source_url': source_url,
            'confidence': confidence,
            'num_clues': len(clues),
            'clue_types': [clue.type for clue in clues]
        }

        self.interaction_history.append(interaction)

        if len(self.interaction_history) > self.max_history:
            self.interaction_history.pop(0)

    def get_interaction_summary(self) -> Dict:
        if not self.interaction_history:
            return {'total_interactions': 0, 'llm_interactions': 0, 'confidence_avg': 0.0}

        total = len(self.interaction_history)
        llm_interactions = sum(1 for i in self.interaction_history if i['confidence'] > 0.6)
        avg_confidence = sum(i['confidence'] for i in self.interaction_history) / total

        return {
            'total_interactions': total,
            'llm_interactions': llm_interactions,
            'confidence_avg': avg_confidence,
            'llm_percentage': (llm_interactions / total) * 100 if total > 0 else 0
        }
