import time
import json
import threading
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


@dataclass
class ApiResponse:
    success: bool
    status_code: int
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


class RetryHandler:
    def __init__(self):
        self.attempt_count = 0
        self.last_attempt_time = 0

    def should_retry(self) -> bool:
        return self.attempt_count < Config.RETRY_MAX_ATTEMPTS

    def get_delay(self) -> float:
        if self.attempt_count == 0:
            return 0

        delay = Config.RETRY_INITIAL_DELAY * (Config.RETRY_MULTIPLIER ** (self.attempt_count - 1))
        return min(delay, Config.RETRY_MAX_DELAY)

    def record_attempt(self) -> None:
        self.attempt_count += 1
        self.last_attempt_time = time.time()

    def reset(self) -> None:
        self.attempt_count = 0
        self.last_attempt_time = 0


class ApiClient:
    def __init__(self):
        self.session = self._create_session()
        self.retry_handler = RetryHandler()
        self._lock = threading.Lock()

    def _create_session(self) -> requests.Session:
        session = requests.Session()

        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'Morrigan-Client/1.0',
            'Authorization': f'Bearer {Config.API_KEY}'
        })

        return session

    def send_events(self, events: List[Dict[str, Any]]) -> ApiResponse:
        if not events:
            return ApiResponse(success=True, status_code=200, data={'message': 'No events to send'})

        with self._lock:
            logger.info(f"Sending batch of {len(events)} events to API")

            try:
                api_events = []
                for event in events:
                    # Remove database metadata fields
                    api_event = {k: v for k, v in event.items()
                               if k not in ['id', 'created_at', 'sent']}
                    
                    # Fix common payload issues
                    if api_event.get('utc_zone') is None or api_event.get('utc_zone') == 'None':
                        api_event['utc_zone'] = 'UTC'
                    
                    # Add required 'type' field if missing (based on server error)
                    if 'type' not in api_event:
                        api_event['type'] = 'monitoring_event'
                    
                    # Ensure all required fields are strings where expected
                    for field in ['trigger_utc', 'io_utc', 'utc_zone', 'endpoint_id', 'file_id', 'action_type']:
                        if field in api_event and api_event[field] is not None:
                            api_event[field] = str(api_event[field])
                    
                    # Ensure numeric fields are properly typed
                    if 'file_size' in api_event:
                        api_event['file_size'] = int(api_event['file_size']) if api_event['file_size'] is not None else 0
                    if 'hu_per' in api_event:
                        api_event['hu_per'] = int(api_event['hu_per']) if api_event['hu_per'] is not None else 0
                    
                    api_events.append(api_event)

                # Log the payload being sent for debugging
                logger.debug(f"API payload: {json.dumps(api_events, indent=2)}")

                response = self.session.post(
                    f"{Config.API_BASE_URL}/event",
                    json=api_events,
                    timeout=Config.API_TIMEOUT
                )

                if response.status_code == 200:
                    logger.info(f"Successfully sent {len(events)} events")
                    self.retry_handler.reset()

                    try:
                        data = response.json()
                    except json.JSONDecodeError:
                        data = {'message': 'Events sent successfully'}

                    return ApiResponse(
                        success=True,
                        status_code=response.status_code,
                        data=data
                    )
                else:
                    error_msg = f"API returned {response.status_code}: {response.text}"
                    logger.warning(error_msg)
                    
                    # Log detailed error for debugging payload issues
                    try:
                        error_data = response.json()
                        logger.error(f"API error details: {json.dumps(error_data, indent=2)}")
                    except json.JSONDecodeError:
                        logger.error(f"API error response (not JSON): {response.text}")

                    return ApiResponse(
                        success=False,
                        status_code=response.status_code,
                        error=error_msg
                    )

            except requests.exceptions.Timeout:
                error_msg = "API request timed out"
                logger.warning(error_msg)
                return ApiResponse(success=False, status_code=408, error=error_msg)

            except requests.exceptions.ConnectionError:
                error_msg = "Could not connect to API"
                logger.warning(error_msg)
                return ApiResponse(success=False, status_code=503, error=error_msg)

            except Exception as e:
                error_msg = f"Unexpected error sending events: {str(e)}"
                logger.error(error_msg)
                return ApiResponse(success=False, status_code=500, error=error_msg)

    def send_events_with_retry(self, events: List[Dict[str, Any]]) -> ApiResponse:
        last_response = None

        while self.retry_handler.should_retry():
            delay = self.retry_handler.get_delay()
            if delay > 0:
                logger.info(f"Waiting {delay:.1f}s before retry attempt {self.retry_handler.attempt_count + 1}")
                time.sleep(delay)

            self.retry_handler.record_attempt()

            response = self.send_events(events)
            last_response = response

            if response.success:
                return response

            if response.status_code in [400, 401, 403]:
                logger.error(f"Client error {response.status_code}, not retrying")
                break

            logger.warning(f"Attempt {self.retry_handler.attempt_count} failed: {response.error}")

        logger.error(f"Failed to send events after {self.retry_handler.attempt_count} attempts")
        return last_response or ApiResponse(success=False, status_code=500, error="Max retries exceeded")

    def test_connection(self) -> ApiResponse:
        try:
            logger.info("Testing API connection")

            response = self.session.get(
                f"{Config.API_BASE_URL}/health",
                timeout=Config.API_TIMEOUT
            )

            if response.status_code == 200:
                logger.info("API connection test successful")
                return ApiResponse(success=True, status_code=200, data={'status': 'connected'})
            else:
                error_msg = f"API health check failed with status {response.status_code}"
                logger.warning(error_msg)
                return ApiResponse(success=False, status_code=response.status_code, error=error_msg)

        except Exception as e:
            error_msg = f"API connection test failed: {str(e)}"
            logger.error(error_msg)
            return ApiResponse(success=False, status_code=500, error=error_msg)

    def validate_config(self) -> List[str]:
        issues = []
        if not Config.API_KEY:
            issues.append("API key not configured")
        if not Config.API_BASE_URL:
            issues.append("API base URL not configured")
        try:
            import urllib.parse
            parsed = urllib.parse.urlparse(Config.API_BASE_URL)
            if not parsed.scheme or not parsed.netloc:
                issues.append("Invalid API base URL format")
        except Exception:
            issues.append("Invalid API base URL")

        return issues


# Global API client instance
api_client = ApiClient()
