#!/usr/bin/env python3
"""
Build script for creating cross-platform Morrigan installer executables
"""

import os
import sys
import shutil
import platform
import subprocess
from pathlib import Path


def build_installer():
    """Build the installer executable"""
    print("Building Morrigan Cross-Platform Installer...")
    
    # Check if PyInstaller is installed
    try:
        import PyInstaller
    except ImportError:
        print("Installing PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Build directory
    project_dir = Path(__file__).parent.parent  # Go up from installer/ to project root
    build_dir = project_dir / "installer_build"
    build_dir.mkdir(exist_ok=True)
    
    # PyInstaller command
    system = platform.system()
    
    if system == "Windows":
        exe_name = "MorriganInstaller.exe"
        icon_flag = []  # Add icon later if available
    else:
        exe_name = "MorriganInstaller"
        icon_flag = []
    
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--windowed" if system == "Windows" else "--console",
        "--name", exe_name.replace(".exe", ""),
        "--distpath", str(build_dir),
        "--workpath", str(build_dir / "work"),
        "--specpath", str(build_dir / "spec"),
        str(Path(__file__).parent / "install.py")  # Use install.py from installer directory
    ]
    
    cmd.extend(icon_flag)
    
    print(f"Running: {' '.join(cmd)}")
    subprocess.check_call(cmd)
    
    # Copy installer to project root
    installer_path = build_dir / exe_name
    final_path = project_dir / exe_name
    
    if installer_path.exists():
        shutil.copy2(installer_path, final_path)
        print(f"Installer created: {final_path}")
        print(f"Size: {final_path.stat().st_size / 1024 / 1024:.1f} MB")
    else:
        print("Error: Installer executable not found!")
        return False
    
    return True


def create_distribution_package():
    """Create a distribution package with installer and source"""
    print("\nCreating distribution package...")
    
    system = platform.system().lower()
    arch = platform.machine().lower()
    
    # Package directory
    project_dir = Path(__file__).parent.parent  # Go up from installer/ to project root
    package_name = f"morrigan-installer-{system}-{arch}"
    package_dir = project_dir / "dist" / package_name
    
    if package_dir.exists():
        shutil.rmtree(package_dir)
    
    package_dir.mkdir(parents=True)
    
    # Copy installer executable
    if system == "windows":
        installer_name = "MorriganInstaller.exe"
    else:
        installer_name = "MorriganInstaller"
    
    installer_src = project_dir / installer_name
    if installer_src.exists():
        shutil.copy2(installer_src, package_dir / installer_name)
    
    # Copy source files (for backup/manual installation)
    src_backup_dir = package_dir / "source"
    src_backup_dir.mkdir()
    
    # Essential files to include
    files_to_copy = [
        "main.py",
        "requirements.txt",
        "README.md",
        ".env.example"
    ]
    
    for file in files_to_copy:
        src_file = project_dir / file
        if src_file.exists():
            shutil.copy2(src_file, src_backup_dir / file)
    
    # Copy src directory
    src_dir = project_dir / "src"
    if src_dir.exists():
        shutil.copytree(src_dir, src_backup_dir / "src")
    
    # Copy installer directory for reference
    installer_backup_dir = src_backup_dir / "installer"
    installer_dir = project_dir / "installer"
    if installer_dir.exists():
        shutil.copytree(installer_dir, installer_backup_dir)
    
    # Create installation instructions
    instructions = f"""# Morrigan LLM Monitor - Installation Instructions

## Automatic Installation (Recommended)

Run the installer executable:

### Windows:
```
MorriganInstaller.exe
```

### macOS/Linux:
```
sudo ./MorriganInstaller
```

The installer will:
1. Prompt for your API credentials
2. Install the monitoring system
3. Set up automatic startup (optional)
4. Create desktop shortcuts (optional)

## Manual Installation (Advanced Users)

If the automatic installer doesn't work:

1. Install Python 3.8+ if not already installed
2. Copy the `source/` directory to your desired location
3. Install dependencies:
   ```
   pip install -r source/requirements.txt
   ```
4. Create configuration:
   ```
   cp source/.env.example source/.env
   # Edit .env with your API credentials
   ```
5. Run the monitor:
   ```
   python source/main.py --real-monitors
   ```

## Configuration

The installer will prompt for:
- **API URL**: Your Morrigan API endpoint
- **API Key**: Your authentication key  
- **Endpoint ID**: Optional unique identifier (auto-generated if not provided)

## System Requirements

- Python 3.8 or higher
- Internet connection for API communication
- Administrator/sudo privileges for system-wide installation

## Uninstallation

The installer creates an uninstaller:
- Windows: `C:\\Program Files\\Morrigan\\uninstall.bat`
- macOS/Linux: `/opt/morrigan/uninstall.sh`

Or run it manually:
```
# Windows
C:\\Program Files\\Morrigan\\uninstall.bat

# macOS/Linux  
sudo /opt/morrigan/uninstall.sh
```

## Support

For issues or questions, please refer to the documentation or contact support.
"""
    
    (package_dir / "INSTALL.md").write_text(instructions)
    
    # Create archive
    archive_path = package_dir.parent / f"{package_name}.zip"
    
    print(f"Creating archive: {archive_path}")
    shutil.make_archive(str(archive_path.with_suffix("")), "zip", str(package_dir.parent), package_name)
    
    print(f"Distribution package created: {archive_path}")
    print(f"Archive size: {archive_path.stat().st_size / 1024 / 1024:.1f} MB")
    
    return archive_path


def main():
    """Main build function"""
    print("Morrigan Cross-Platform Installer Builder")
    print("=" * 50)
    
    try:
        # Build installer executable
        if build_installer():
            print("✅ Installer executable built successfully")
            
            # Create distribution package
            archive_path = create_distribution_package()
            print("✅ Distribution package created successfully")
            
            print(f"\n🎉 Build complete!")
            print(f"📦 Distribution: {archive_path}")
            print("\nTo distribute:")
            print("1. Upload the .zip file to your distribution platform")
            print("2. Users download and extract the archive")
            print("3. Users run the installer executable")
            print("4. Installer prompts for API credentials and installs automatically")
            
        else:
            print("❌ Build failed")
            return False
            
    except Exception as e:
        print(f"❌ Build error: {e}")
        return False
    
    return True


if __name__ == "__main__":
    main()
