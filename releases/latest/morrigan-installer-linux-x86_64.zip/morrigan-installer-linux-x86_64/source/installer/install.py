#!/usr/bin/env python3
"""
Morrigan LLM Monitor - Cross-Platform Installer
Interactive installer that prompts for API credentials and installs the monitoring system.
"""

import os
import sys
import json
import shutil
import platform
import subprocess
from pathlib import Path
from typing import Dict, Optional, Tuple

# Try to import tkinter, but don't fail if it's not available
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, simpledialog
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    # Create dummy classes for when tkinter is not available
    class tk:
        class Tk: pass
        class StringVar: 
            def __init__(self, value=""): self.value = value
            def get(self): return self.value
            def set(self, value): self.value = value
        class BooleanVar:
            def __init__(self, value=False): self.value = value
            def get(self): return self.value
            def set(self, value): self.value = value
        class DoubleVar:
            def __init__(self, value=0.0): self.value = value
            def get(self): return self.value
            def set(self, value): self.value = value
        W = E = N = S = LEFT = "dummy"
    
    class ttk:
        class Frame: pass
        class Label: pass
        class Entry: pass
        class Button: pass
        class Checkbutton: pass
        class Progressbar: pass
        class LabelFrame: pass
    
    class messagebox:
        @staticmethod
        def showerror(title, message): print(f"ERROR: {message}")
        @staticmethod
        def showinfo(title, message): print(f"INFO: {message}")
    
    class simpledialog: pass


class MorriganInstaller:
    def __init__(self):
        self.platform = platform.system()
        self.is_windows = self.platform == "Windows"
        self.is_macos = self.platform == "Darwin"
        self.is_linux = self.platform == "Linux"
        
        # Installation paths
        if self.is_windows:
            self.install_dir = Path("C:/Program Files/Morrigan")
            self.data_dir = Path("C:/ProgramData/Morrigan")
            self.config_dir = self.data_dir
        else:
            self.install_dir = Path("/opt/morrigan")
            self.data_dir = Path.home() / ".morrigan"
            self.config_dir = self.data_dir
            
        # Find the project source directory (go up from installer/ to project root)
        installer_dir = Path(__file__).parent
        self.source_dir = installer_dir.parent
        self.config = {}
        
    def run_gui_installer(self):
        """Run the GUI installer"""
        root = tk.Tk()
        root.title("Morrigan LLM Monitor - Installer")
        root.geometry("600x500")
        root.resizable(False, False)
        
        # Center the window
        root.update_idletasks()
        x = (root.winfo_screenwidth() // 2) - (600 // 2)
        y = (root.winfo_screenheight() // 2) - (500 // 2)
        root.geometry(f"600x500+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(root, padding="20")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="Morrigan LLM Monitor Installer", 
                               font=("TkDefaultFont", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Description
        desc_text = """This installer will set up the Morrigan LLM monitoring system on your computer.
        
The system monitors your interactions with AI tools and sends anonymized 
metadata to help improve LLM usage insights.

Please provide your API credentials below:"""
        
        desc_label = ttk.Label(main_frame, text=desc_text, wraplength=550, justify="left")
        desc_label.grid(row=1, column=0, columnspan=2, pady=(0, 20))
        
        # API URL
        ttk.Label(main_frame, text="API URL:").grid(row=2, column=0, sticky=tk.W, pady=5)
        api_url_var = tk.StringVar(value="https://morrigan-poc-serverless.azurewebsites.net/api")
        api_url_entry = ttk.Entry(main_frame, textvariable=api_url_var, width=50)
        api_url_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # API Key
        ttk.Label(main_frame, text="API Key:").grid(row=3, column=0, sticky=tk.W, pady=5)
        api_key_var = tk.StringVar()
        api_key_entry = ttk.Entry(main_frame, textvariable=api_key_var, width=50, show="*")
        api_key_entry.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Endpoint ID (optional)
        ttk.Label(main_frame, text="Endpoint ID:").grid(row=4, column=0, sticky=tk.W, pady=5)
        endpoint_id_var = tk.StringVar()
        endpoint_id_entry = ttk.Entry(main_frame, textvariable=endpoint_id_var, width=50)
        endpoint_id_entry.grid(row=4, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        ttk.Label(main_frame, text="(Optional - will auto-generate if empty)", 
                 font=("TkDefaultFont", 8)).grid(row=5, column=1, sticky=tk.W, padx=(10, 0))
        
        # Installation options
        options_frame = ttk.LabelFrame(main_frame, text="Installation Options", padding="10")
        options_frame.grid(row=6, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=20)
        
        auto_start_var = tk.BooleanVar(value=True)
        auto_start_check = ttk.Checkbutton(options_frame, 
                                          text="Start monitoring automatically on system boot",
                                          variable=auto_start_var)
        auto_start_check.grid(row=0, column=0, sticky=tk.W)
        
        create_shortcut_var = tk.BooleanVar(value=True)
        create_shortcut_check = ttk.Checkbutton(options_frame, 
                                               text="Create desktop shortcut",
                                               variable=create_shortcut_var)
        create_shortcut_check.grid(row=1, column=0, sticky=tk.W)
        
        # Progress bar
        progress_var = tk.DoubleVar()
        progress_bar = ttk.Progressbar(main_frame, variable=progress_var, maximum=100)
        progress_bar.grid(row=7, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10)
        
        # Status label
        status_var = tk.StringVar(value="Ready to install")
        status_label = ttk.Label(main_frame, textvariable=status_var)
        status_label.grid(row=8, column=0, columnspan=2, pady=5)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=9, column=0, columnspan=2, pady=20)
        
        def on_install():
            # Validate inputs
            if not api_key_var.get().strip():
                messagebox.showerror("Error", "API Key is required!")
                return
                
            if not api_url_var.get().strip():
                messagebox.showerror("Error", "API URL is required!")
                return
            
            # Disable install button
            install_button.config(state="disabled")
            cancel_button.config(text="Close", command=root.destroy)
            
            # Set configuration
            self.config = {
                "api_url": api_url_var.get().strip(),
                "api_key": api_key_var.get().strip(),
                "endpoint_id": endpoint_id_var.get().strip() or None,
                "auto_start": auto_start_var.get(),
                "create_shortcut": create_shortcut_var.get()
            }
            
            # Run installation
            try:
                self._run_installation_steps(progress_var, status_var, root)
                messagebox.showinfo("Success", "Morrigan LLM Monitor installed successfully!")
                root.destroy()
            except Exception as e:
                messagebox.showerror("Installation Error", f"Installation failed: {str(e)}")
                install_button.config(state="normal")
                cancel_button.config(text="Cancel", command=root.destroy)
        
        install_button = ttk.Button(button_frame, text="Install", command=on_install)
        install_button.pack(side=tk.LEFT, padx=(0, 10))
        
        cancel_button = ttk.Button(button_frame, text="Cancel", command=root.destroy)
        cancel_button.pack(side=tk.LEFT)
        
        # Configure grid weights
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Focus on API key field
        api_key_entry.focus()
        
        root.mainloop()
        
    def _run_installation_steps(self, progress_var, status_var, root):
        """Run the installation steps with progress updates"""
        steps = [
            ("Checking system requirements", self._check_requirements),
            ("Creating directories", self._create_directories),
            ("Installing files", self._install_files),
            ("Creating configuration", self._create_config),
            ("Installing dependencies", self._install_dependencies),
            ("Setting up service", self._setup_service),
            ("Creating shortcuts", self._create_shortcuts),
            ("Finalizing installation", self._finalize_installation)
        ]
        
        for i, (description, step_func) in enumerate(steps):
            status_var.set(description + "...")
            root.update()
            
            step_func()
            
            progress = ((i + 1) / len(steps)) * 100
            progress_var.set(progress)
            root.update()
    
    def _check_requirements(self):
        """Check system requirements"""
        # Check Python version
        if sys.version_info < (3, 8):
            raise Exception("Python 3.8 or higher is required")
        
        # Check if running as admin/root
        if self.is_windows:
            try:
                import ctypes
                if not ctypes.windll.shell32.IsUserAnAdmin():
                    raise Exception("Please run installer as Administrator")
            except:
                pass  # Assume we have permissions
        else:
            if os.geteuid() != 0 and str(self.install_dir).startswith("/opt"):
                raise Exception("Please run installer with sudo privileges")
    
    def _create_directories(self):
        """Create necessary directories"""
        self.install_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Set permissions on Unix systems
        if not self.is_windows:
            os.chmod(self.data_dir, 0o755)
            os.chmod(self.config_dir, 0o755)
    
    def _install_files(self):
        """Copy application files"""
        # Copy all source files
        src_dir = self.source_dir / "src"
        dest_dir = self.install_dir / "src"
        
        if dest_dir.exists():
            shutil.rmtree(dest_dir)
        
        shutil.copytree(src_dir, dest_dir)
        
        # Copy main script
        shutil.copy2(self.source_dir / "main.py", self.install_dir / "main.py")
        
        # Copy requirements
        shutil.copy2(self.source_dir / "requirements.txt", self.install_dir / "requirements.txt")
        
        # Make executable on Unix
        if not self.is_windows:
            os.chmod(self.install_dir / "main.py", 0o755)
    
    def _create_config(self):
        """Create configuration files"""
        # Create .env file
        env_content = f"""ENV=production
API_URL={self.config['api_url']}
API_KEY={self.config['api_key']}
MORRIGAN_MODE=production
MORRIGAN_SILENT=true
MORRIGAN_AUTO_START=true
"""
        
        env_path = self.install_dir / ".env"
        env_path.write_text(env_content)
        
        # Create endpoint_id.txt if provided
        if self.config.get('endpoint_id'):
            endpoint_path = self.config_dir / "endpoint_id.txt"
            endpoint_path.write_text(self.config['endpoint_id'])
    
    def _install_dependencies(self):
        """Install Python dependencies"""
        pip_cmd = [sys.executable, "-m", "pip", "install", "-r", str(self.install_dir / "requirements.txt")]
        
        result = subprocess.run(pip_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise Exception(f"Failed to install dependencies: {result.stderr}")
    
    def _setup_service(self):
        """Set up system service"""
        if not self.config.get('auto_start'):
            return
            
        if self.is_windows:
            self._setup_windows_service()
        elif self.is_macos:
            self._setup_macos_service()
        elif self.is_linux:
            self._setup_linux_service()
    
    def _setup_windows_service(self):
        """Set up Windows service"""
        # Create Windows service script
        service_script = f'''@echo off
cd /d "{self.install_dir}"
python main.py --real-monitors
'''
        
        script_path = self.install_dir / "start_morrigan.bat"
        script_path.write_text(service_script)
        
        # Add to startup folder
        startup_folder = Path(os.getenv("APPDATA")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
        startup_script = startup_folder / "Morrigan.bat"
        
        startup_folder.mkdir(parents=True, exist_ok=True)
        shutil.copy2(script_path, startup_script)
    
    def _setup_macos_service(self):
        """Set up macOS LaunchAgent"""
        plist_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.morrigan.monitor</string>
    <key>ProgramArguments</key>
    <array>
        <string>{sys.executable}</string>
        <string>{self.install_dir / "main.py"}</string>
        <string>--real-monitors</string>
    </array>
    <key>WorkingDirectory</key>
    <string>{self.install_dir}</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{self.data_dir / "morrigan.out.log"}</string>
    <key>StandardErrorPath</key>
    <string>{self.data_dir / "morrigan.err.log"}</string>
</dict>
</plist>'''
        
        launch_agents_dir = Path.home() / "Library" / "LaunchAgents"
        launch_agents_dir.mkdir(parents=True, exist_ok=True)
        
        plist_path = launch_agents_dir / "com.morrigan.monitor.plist"
        plist_path.write_text(plist_content)
        
        # Load the service
        subprocess.run(["launchctl", "load", str(plist_path)], check=False)
    
    def _setup_linux_service(self):
        """Set up Linux systemd service"""
        service_content = f'''[Unit]
Description=Morrigan LLM Monitor
After=network.target

[Service]
Type=simple
User={os.getenv("USER", "root")}
WorkingDirectory={self.install_dir}
ExecStart={sys.executable} {self.install_dir / "main.py"} --real-monitors
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
'''
        
        service_path = Path("/etc/systemd/system/morrigan.service")
        service_path.write_text(service_content)
        
        # Enable and start service
        subprocess.run(["systemctl", "daemon-reload"], check=False)
        subprocess.run(["systemctl", "enable", "morrigan"], check=False)
    
    def _create_shortcuts(self):
        """Create desktop shortcuts"""
        if not self.config.get('create_shortcut'):
            return
            
        if self.is_windows:
            self._create_windows_shortcut()
        elif self.is_macos:
            self._create_macos_shortcut()
        elif self.is_linux:
            self._create_linux_shortcut()
    
    def _create_windows_shortcut(self):
        """Create Windows desktop shortcut"""
        try:
            import win32com.client
            shell = win32com.client.Dispatch("WScript.Shell")
            
            desktop = shell.SpecialFolders("Desktop")
            shortcut_path = os.path.join(desktop, "Morrigan Monitor.lnk")
            
            shortcut = shell.CreateShortCut(shortcut_path)
            shortcut.Targetpath = str(self.install_dir / "start_morrigan.bat")
            shortcut.WorkingDirectory = str(self.install_dir)
            shortcut.IconLocation = str(self.install_dir / "start_morrigan.bat")
            shortcut.save()
        except ImportError:
            # win32com not available, create simple batch file instead
            desktop_dir = Path(os.path.expanduser("~/Desktop"))
            if desktop_dir.exists():
                shortcut_content = f'@echo off\ncd /d "{self.install_dir}"\ncall start_morrigan.bat'
                shortcut_path = desktop_dir / "Morrigan Monitor.bat"
                shortcut_path.write_text(shortcut_content)
        except Exception:
            pass  # Skip if any other error occurs
    
    def _create_macos_shortcut(self):
        """Create macOS application bundle"""
        # Create simple app bundle structure
        app_path = Path("/Applications/Morrigan Monitor.app")
        app_path.mkdir(parents=True, exist_ok=True)
        
        contents_path = app_path / "Contents"
        contents_path.mkdir(exist_ok=True)
        
        macos_path = contents_path / "MacOS"
        macos_path.mkdir(exist_ok=True)
        
        # Create executable script
        script_content = f'''#!/bin/bash
cd "{self.install_dir}"
{sys.executable} main.py --real-monitors
'''
        
        exec_path = macos_path / "Morrigan Monitor"
        exec_path.write_text(script_content)
        os.chmod(exec_path, 0o755)
        
        # Create Info.plist
        info_plist = f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>Morrigan Monitor</string>
    <key>CFBundleIdentifier</key>
    <string>com.morrigan.monitor</string>
    <key>CFBundleName</key>
    <string>Morrigan Monitor</string>
    <key>CFBundleVersion</key>
    <string>1.0</string>
</dict>
</plist>'''
        
        (contents_path / "Info.plist").write_text(info_plist)
    
    def _create_linux_shortcut(self):
        """Create Linux desktop entry"""
        desktop_entry = f'''[Desktop Entry]
Version=1.0
Type=Application
Name=Morrigan Monitor
Comment=LLM Monitoring System
Exec={sys.executable} {self.install_dir / "main.py"} --real-monitors
Path={self.install_dir}
Terminal=false
StartupNotify=true
Categories=Utility;
'''
        
        desktop_path = Path.home() / "Desktop" / "morrigan-monitor.desktop"
        desktop_path.write_text(desktop_entry)
        os.chmod(desktop_path, 0o755)
        
        # Also install to applications
        apps_dir = Path.home() / ".local" / "share" / "applications"
        apps_dir.mkdir(parents=True, exist_ok=True)
        
        app_desktop = apps_dir / "morrigan-monitor.desktop"
        app_desktop.write_text(desktop_entry)
        os.chmod(app_desktop, 0o755)
    
    def _finalize_installation(self):
        """Finalize the installation"""
        # Create uninstaller
        self._create_uninstaller()
        
        # Set final permissions
        if not self.is_windows:
            subprocess.run(["chmod", "-R", "755", str(self.install_dir)], check=False)
    
    def _create_uninstaller(self):
        """Create uninstaller script"""
        if self.is_windows:
            uninstall_content = f'''@echo off
echo Uninstalling Morrigan LLM Monitor...

REM Stop any running processes
taskkill /f /im python.exe 2>nul

REM Remove startup script
del "%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\Morrigan.bat" 2>nul

REM Remove desktop shortcut
del "%USERPROFILE%\\Desktop\\Morrigan Monitor.lnk" 2>nul

REM Remove installation directory
rmdir /s /q "{self.install_dir}" 2>nul

REM Remove data directory
rmdir /s /q "{self.data_dir}" 2>nul

echo Uninstallation complete.
pause
'''
            uninstall_path = self.install_dir / "uninstall.bat"
        else:
            uninstall_content = f'''#!/bin/bash
echo "Uninstalling Morrigan LLM Monitor..."

# Stop service
if command -v systemctl &> /dev/null; then
    sudo systemctl stop morrigan 2>/dev/null
    sudo systemctl disable morrigan 2>/dev/null
    sudo rm -f /etc/systemd/system/morrigan.service
    sudo systemctl daemon-reload
fi

# Remove LaunchAgent (macOS)
if [[ "$OSTYPE" == "darwin"* ]]; then
    launchctl unload ~/Library/LaunchAgents/com.morrigan.monitor.plist 2>/dev/null
    rm -f ~/Library/LaunchAgents/com.morrigan.monitor.plist
    rm -rf "/Applications/Morrigan Monitor.app"
fi

# Remove desktop entries (Linux)
rm -f ~/Desktop/morrigan-monitor.desktop
rm -f ~/.local/share/applications/morrigan-monitor.desktop

# Remove installation directory
sudo rm -rf "{self.install_dir}"

# Remove data directory
rm -rf "{self.data_dir}"

echo "Uninstallation complete."
'''
            uninstall_path = self.install_dir / "uninstall.sh"
            
        uninstall_path.write_text(uninstall_content)
        if not self.is_windows:
            os.chmod(uninstall_path, 0o755)


def main():
    """Main installer entry point"""
    print("Morrigan LLM Monitor - Cross-Platform Installer")
    print("=" * 50)
    
    # Check if GUI is available
    gui_available = False
    if TKINTER_AVAILABLE:
        try:
            # Test if display is available
            root = tk.Tk()
            root.withdraw()
            root.destroy()
            gui_available = True
        except Exception as e:
            print(f"GUI not available: {e}")
            gui_available = False
    else:
        print("tkinter not available, using console mode")
    
    installer = MorriganInstaller()
    
    if gui_available and "--console" not in sys.argv:
        print("Starting GUI installer...")
        try:
            installer.run_gui_installer()
        except Exception as e:
            print(f"GUI installer failed: {e}")
            print("Falling back to console installer...")
            run_console_installer(installer)
    else:
        # Run console installer
        run_console_installer(installer)


def run_console_installer(installer):
    """Run the console-based installer"""
    print("Running console installer...")
    print("\nThis will install the Morrigan LLM monitoring system.")
    print("Please provide your API credentials:\n")
    
    # Get user input
    default_url = "https://morrigan-poc-serverless.azurewebsites.net/api"
    api_url = input(f"API URL [{default_url}]: ").strip()
    if not api_url:
        api_url = default_url
        
    api_key = input("API Key: ").strip()
    if not api_key:
        print("Error: API Key is required!")
        sys.exit(1)
        
    endpoint_id = input("Endpoint ID (optional): ").strip() or None
    
    auto_start = input("Start automatically on boot? [Y/n]: ").strip().lower()
    auto_start = auto_start != 'n'
    
    installer.config = {
        "api_url": api_url,
        "api_key": api_key,
        "endpoint_id": endpoint_id,
        "auto_start": auto_start,
        "create_shortcut": True
    }
    
    # Run installation
    try:
        print("\nInstalling...")
        
        class DummyVar:
            def set(self, value): 
                print(f"Progress: {value}")
        
        class DummyRoot:
            def update(self): pass
        
        status_var = DummyVar()
        installer._run_installation_steps(DummyVar(), status_var, DummyRoot())
        print("\n✅ Installation completed successfully!")
        print(f"Monitoring system installed to: {installer.install_dir}")
        print(f"Configuration stored in: {installer.config_dir}")
        
        if installer.config.get('auto_start'):
            print("✅ Auto-start configured - monitoring will start on next boot")
        
        print("\nTo start monitoring now:")
        if installer.is_windows:
            print(f'  Run: "{installer.install_dir}/start_morrigan.bat"')
        else:
            print(f'  Run: python "{installer.install_dir}/main.py" --real-monitors')
        
    except Exception as e:
        print(f"❌ Installation failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
