#!/usr/bin/env python3
"""
Script to update the distribution repository with new builds
"""

import shutil
import sys
import platform
from pathlib import Path
import hashlib

def calculate_checksums(dist_dir):
    """Calculate checksums for all files"""
    checksums = []
    for file_path in dist_dir.glob("*.zip"):
        with open(file_path, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()
        checksums.append(f"{file_hash}  {file_path.name}")

    return "\n".join(checksums)

def update_distribution(version, dist_dir, release_repo):
    """Update the distribution repository"""
    dist_dir = Path(dist_dir)
    release_repo = Path(release_repo)

    # Create version directory
    version_dir = release_repo / "releases" / version
    version_dir.mkdir(parents=True, exist_ok=True)

    # Copy distribution files
    for zip_file in dist_dir.glob("*.zip"):
        shutil.copy2(zip_file, version_dir)
        print(f"✅ Copied {zip_file.name}")

    # Generate checksums
    checksums = calculate_checksums(version_dir)
    with open(version_dir / "checksums.txt", 'w') as f:
        f.write(checksums)
    print("✅ Generated checksums")

    # Update latest symlinks/copies
    latest_dir = release_repo / "releases" / "latest"
    latest_dir.mkdir(exist_ok=True)

    for zip_file in version_dir.glob("*.zip"):
        latest_file = latest_dir / zip_file.name
        if latest_file.exists():
            latest_file.unlink()
        
        # Use symlinks on Unix-like systems, copy on Windows
        if platform.system() == "Windows":
            shutil.copy2(zip_file, latest_file)
        else:
            latest_file.symlink_to(f"../{version}/{zip_file.name}")

    print(f"✅ Updated latest release to {version}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python update_release.py <version> <dist_dir> <release_repo>")
        print("Example: python update_release.py v1.0.0 ../dist /path/to/morrigan-releases")
        sys.exit(1)

    version, dist_dir, release_repo = sys.argv[1:4]
    update_distribution(version, dist_dir, release_repo)
    print(f"\n🎉 Release {version} ready for distribution!")
