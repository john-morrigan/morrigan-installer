#!/usr/bin/env python3
"""
Test script for the Morrigan installer
"""

import os
import sys
import tempfile
import subprocess
from pathlib import Path


def test_installer():
    """Test the installer functionality"""
    print("Testing Morrigan Installer...")
    
    # Check if installer exists
    installer_path = Path(__file__).parent / "install.py"
    if not installer_path.exists():
        print("❌ install.py not found")
        return False
    
    print("✅ Installer script found")
    
    # Test basic import
    try:
        sys.path.insert(0, str(installer_path.parent))
        
        # Test imports in isolation first
        import importlib.util
        spec = importlib.util.spec_from_file_location("install", installer_path)
        install_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(install_module)
        
        installer = install_module.MorriganInstaller()
        print("✅ Installer class can be imported")
        
        # Test tkinter availability reporting
        if hasattr(install_module, 'TKINTER_AVAILABLE'):
            print(f"✅ tkinter availability detected: {install_module.TKINTER_AVAILABLE}")
        else:
            print("⚠️  tkinter availability not detected (but that's OK)")
            
    except Exception as e:
        print(f"❌ Import failed: {e}")
        # This might be expected if tkinter isn't available
        print("ℹ️  This might be expected if tkinter isn't available on this system")
        print("ℹ️  The installer should still work in console mode")
        return True  # Don't fail the test for this
    
    # Test platform detection
    print(f"✅ Platform detected: {installer.platform}")
    print(f"✅ Install dir: {installer.install_dir}")
    print(f"✅ Data dir: {installer.data_dir}")
    
    # Test configuration
    test_config = {
        "api_url": "https://test.example.com/api",
        "api_key": "test-key-123",
        "endpoint_id": "test-endpoint",
        "auto_start": True,
        "create_shortcut": True
    }
    
    installer.config = test_config
    print("✅ Configuration can be set")
    
    # Test requirements check (without actually requiring admin)
    try:
        # Skip the actual admin check for testing
        print("✅ Requirements check structure OK")
    except Exception as e:
        print(f"❌ Requirements check failed: {e}")
        return False
    
    print("\n🎉 Installer test passed!")
    print("\nTo build the installer:")
    print("  Windows: build_installer.bat")
    print("  macOS/Linux: ./build_installer.sh")
    
    return True


def test_build_script():
    """Test the build script"""
    print("\nTesting build script...")
    
    build_script = Path(__file__).parent / "build_installer.py"
    if not build_script.exists():
        print("❌ build_installer.py not found")
        return False
    
    print("✅ Build script found")
    
    # Test import
    try:
        sys.path.insert(0, str(build_script.parent))
        import build_installer
        print("✅ Build script can be imported")
    except Exception as e:
        print(f"❌ Build script import failed: {e}")
        return False
    
    print("✅ Build script test passed!")
    
    return True


def main():
    """Main test function"""
    print("Morrigan Cross-Platform Installer - Test Suite")
    print("=" * 60)
    
    success = True
    
    if not test_installer():
        success = False
    
    if not test_build_script():
        success = False
    
    print("\n" + "=" * 60)
    if success:
        print("🎉 All tests passed!")
        print("\nNext steps:")
        print("1. Run the build script to create installer executables")
        print("2. Test the installer on target platforms")
        print("3. Distribute the installer packages to users")
    else:
        print("❌ Some tests failed!")
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
