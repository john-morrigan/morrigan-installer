# Morrigan LLM Monitor - Installation Instructions

## Automatic Installation (Recommended)

Run the installer executable:

### Windows:
```
MorriganInstaller.exe
```

### macOS/Linux:
```
sudo ./MorriganInstaller
```

The installer will:
1. Prompt for your API credentials
2. Install the monitoring system
3. Set up automatic startup (optional)
4. Create desktop shortcuts (optional)

## Manual Installation (Advanced Users)

If the automatic installer doesn't work:

1. Install Python 3.8+ if not already installed
2. Copy the `source/` directory to your desired location
3. Install dependencies:
   ```
   pip install -r source/requirements.txt
   ```
4. Create configuration:
   ```
   cp source/.env.example source/.env
   # Edit .env with your API credentials
   ```
5. Run the monitor:
   ```
   python source/main.py --real-monitors
   ```

## Configuration

The installer will prompt for:
- **API URL**: Your Morrigan API endpoint
- **API Key**: Your authentication key  
- **Endpoint ID**: Optional unique identifier (auto-generated if not provided)

## System Requirements

- Python 3.8 or higher
- Internet connection for API communication
- Administrator/sudo privileges for system-wide installation

## Uninstallation

The installer creates an uninstaller:
- Windows: `C:\Program Files\Morrigan\uninstall.bat`
- macOS/Linux: `/opt/morrigan/uninstall.sh`

Or run it manually:
```
# Windows
C:\Program Files\Morrigan\uninstall.bat

# macOS/Linux  
sudo /opt/morrigan/uninstall.sh
```

## Support

For issues or questions, please refer to the documentation or contact support.
