import platform
from abc import ABC, abstractmethod
from typing import Optional

from ..logger import get_logger

logger = get_logger(__name__)


class CrossPlatformClipboard(ABC):

    @abstractmethod
    def get_text(self) -> Optional[str]:
        """Get text from clipboard"""
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if clipboard access is available"""
        pass


class PyperclipImplementation(CrossPlatformClipboard):
    """Cross-platform clipboard using pyperclip"""

    def __init__(self):
        try:
            import pyperclip
            self.pyperclip = pyperclip
            self._available = True
            logger.debug("Pyperclip clipboard implementation initialized")
        except ImportError:
            self._available = False
            logger.error("Pyperclip not available - clipboard monitoring disabled")

    def get_text(self) -> Optional[str]:
        if not self._available:
            return None
        try:
            return self.pyperclip.paste()
        except Exception as e:
            logger.error(f"Failed to get clipboard text: {e}")
            return None

    def is_available(self) -> bool:
        return self._available


class MacOSClipboard(CrossPlatformClipboard):
    """macOS native clipboard implementation"""

    def __init__(self):
        try:
            from AppKit import NSPasteboard, NSStringPboardType
            self.pasteboard = NSPasteboard.generalPasteboard
            self.string_type = NSStringPboardType
            self._available = True
            logger.debug("macOS native clipboard implementation initialized")
        except ImportError:
            self._available = False
            logger.warning("macOS AppKit not available, falling back to pyperclip")

    def get_text(self) -> Optional[str]:
        if not self._available:
            return None
        try:
            return self.pasteboard().stringForType_(self.string_type)
        except Exception as e:
            logger.error(f"Failed to get macOS clipboard text: {e}")
            return None

    def is_available(self) -> bool:
        return self._available


class LinuxClipboard(CrossPlatformClipboard):
    """Linux clipboard implementation using subprocess"""

    def __init__(self):
        import shutil
        self.xclip_available = shutil.which('xclip') is not None
        self.xsel_available = shutil.which('xsel') is not None
        self._available = self.xclip_available or self.xsel_available

        if self._available:
            logger.debug(f"Linux clipboard initialized (xclip: {self.xclip_available}, xsel: {self.xsel_available})")
        else:
            logger.warning("Neither xclip nor xsel available on Linux")

    def get_text(self) -> Optional[str]:
        if not self._available:
            return None

        import subprocess
        try:
            if self.xclip_available:
                result = subprocess.run(['xclip', '-selection', 'clipboard', '-o'],
                                      capture_output=True, text=True, timeout=2)
                if result.returncode == 0:
                    return result.stdout

            if self.xsel_available:
                result = subprocess.run(['xsel', '--clipboard', '--output'],
                                      capture_output=True, text=True, timeout=2)
                if result.returncode == 0:
                    return result.stdout

        except Exception as e:
            logger.error(f"Failed to get Linux clipboard text: {e}")

        return None

    def is_available(self) -> bool:
        return self._available


def get_clipboard_implementation() -> CrossPlatformClipboard:
    """Factory function to get the best clipboard implementation for current platform"""
    system = platform.system()

    if system == "Darwin":
        macos_impl = MacOSClipboard()
        if macos_impl.is_available():
            return macos_impl

    elif system == "Linux":
        linux_impl = LinuxClipboard()
        if linux_impl.is_available():
            return linux_impl

    return PyperclipImplementation()
