import signal
import threading
from typing import Dict, Any, List

from ..config import Config
from ..logger import get_logger
from ..storage.event_queue import EventQueue
from .event_sender import EventSender
from .base_monitor import BaseMonitor
from .real_clipboard_monitor import RealClipboardMonitor
from .filesystem_monitor import FileSystemMonitor
from .window_monitor import WindowMonitor

logger = get_logger(__name__)


class MonitoringService:
    def __init__(self):
        self.running = False
        self.event_queue = EventQueue()
        self.event_sender = EventSender(self.event_queue)
        self.monitors: List[BaseMonitor] = []
        self._shutdown_event = threading.Event()

        self._setup_signal_handlers()

        logger.info("Monitoring service initialized")

    def add_monitor(self, monitor: BaseMonitor) -> None:
        self.monitors.append(monitor)
        logger.info(f"Added monitor: {monitor.name}")

    def start(self) -> bool:
        try:
            logger.info("Starting Morrigan monitoring service...")

            config_issues = Config.validate_config()
            if config_issues:
                for issue in config_issues:
                    logger.error(f"Configuration issue: {issue}")
                if not Config.IS_DEVELOPMENT:
                    return False
                logger.warning("Continuing in development mode despite config issues")

            Config.ensure_data_directory()

            self.event_sender.start()

            for monitor in self.monitors:
                try:
                    monitor.start_monitoring()
                    logger.info(f"Started monitor: {monitor.name}")
                except Exception as e:
                    logger.error(f"Failed to start monitor {monitor.name}: {e}")

            self.running = True
            logger.info("Morrigan monitoring service started successfully")

            return True

        except Exception as e:
            logger.error(f"Failed to start monitoring service: {e}")
            self.stop()
            return False

    def stop(self) -> None:
        if not self.running:
            return

        logger.info("Stopping Morrigan monitoring service...")
        self.running = False

        for monitor in self.monitors:
            try:
                monitor.stop_monitoring()
                logger.info(f"Stopped monitor: {monitor.name}")
            except Exception as e:
                logger.error(f"Error stopping monitor {monitor.name}: {e}")

        try:
            logger.info("Sending remaining events before shutdown...")
            self.event_sender.force_send()
        except Exception as e:
            logger.error(f"Error sending final events: {e}")

        self.event_sender.stop()

        self._shutdown_event.set()

        logger.info("Morrigan monitoring service stopped")

    def run(self) -> None:
        if not self.start():
            logger.error("Failed to start service")
            return

        try:
            logger.info("Monitoring service running. Press Ctrl+C to stop.")

            while self.running and not self._shutdown_event.is_set():
                self._log_status()
                self._shutdown_event.wait(timeout=300)  # 5 minutes

        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt")
        except Exception as e:
            logger.error(f"Error in service main loop: {e}")
        finally:
            self.stop()

    def get_status(self) -> Dict[str, Any]:
        monitor_status = {}
        for monitor in self.monitors:
            monitor_status[monitor.name] = {
                'running': monitor.running
            }

        sender_status = self.event_sender.get_status()
        queue_stats = self.event_queue.get_queue_stats()

        return {
            'service_running': self.running,
            'monitors': monitor_status,
            'event_sender': sender_status,
            'event_queue': queue_stats,
            'config_valid': len(Config.validate_config()) == 0
        }

    def _setup_signal_handlers(self) -> None:
        def signal_handler(signum, frame):
            logger.info(f"Received signal {signum}, initiating shutdown...")
            self.stop()

        try:
            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)

            if Config.IS_WINDOWS:
                signal.signal(signal.SIGBREAK, signal_handler)

        except Exception as e:
            logger.warning(f"Could not setup signal handlers: {e}")

    def _log_status(self) -> None:
        try:
            status = self.get_status()

            queue_stats = status.get('event_queue', {})
            sender_stats = status.get('event_sender', {})

            pending_events = queue_stats.get('pending_events', 0)
            total_events = queue_stats.get('total_events', 0)

            logger.info(
                f"Status: {pending_events} pending events, "
                f"{total_events} total events, "
                f"sender running: {sender_stats.get('running', False)}"
            )

            for monitor_name, monitor_info in status.get('monitors', {}).items():
                if not monitor_info.get('running', False):
                    logger.warning(f"Monitor {monitor_name} is not running")

        except Exception as e:
            logger.error(f"Error logging status: {e}")

    def create_real_monitors(self) -> None:
        """Create real monitoring instances for cross-platform operation"""
        try:
            clipboard_monitor = RealClipboardMonitor(self.event_queue)
            self.add_monitor(clipboard_monitor)

            filesystem_monitor = FileSystemMonitor(self.event_queue)
            self.add_monitor(filesystem_monitor)

            window_monitor = WindowMonitor(self.event_queue)
            self.add_monitor(window_monitor)

            logger.info("Created real monitors for cross-platform operation")

        except Exception as e:
            logger.error(f"Error creating real monitors: {e}")
