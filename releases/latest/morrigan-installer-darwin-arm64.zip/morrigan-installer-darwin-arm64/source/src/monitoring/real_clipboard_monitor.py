import platform
import time
import threading
import hashlib
from typing import Optional, Dict, Any, List
from pathlib import Path

from .base_monitor import BaseMonitor
from .clipboard_utils import get_clipboard_implementation
from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


class RealClipboardMonitor(BaseMonitor):
    """Cross-platform clipboard monitor with LLM detection"""
    
    def __init__(self, event_queue):
        super().__init__("RealClipboardMonitor")
        self.event_queue = event_queue
        self.monitoring_thread = None
        self.stop_event = threading.Event()
        self.last_clipboard_hash = None
        self.clipboard_history: List[Dict[str, Any]] = []
        self.max_history = 10
        
        # Get cross-platform clipboard implementation
        self.clipboard_impl = get_clipboard_implementation()
        
    def start_monitoring(self) -> None:
        """Start clipboard monitoring"""
        if self.running:
            logger.warning("Clipboard monitor already running")
            return
            
        if not self.clipboard_impl.is_available():
            logger.error("Clipboard access not available")
            return
            
        self.running = True
        self.stop_event.clear()
        self.monitoring_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitoring_thread.start()
        logger.info("Real clipboard monitoring started")
        
    def stop_monitoring(self) -> None:
        """Stop clipboard monitoring"""
        if not self.running:
            return
            
        self.running = False
        self.stop_event.set()
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=2)
            
        logger.info("Clipboard monitoring stopped")
        
    def _monitor_loop(self) -> None:
        """Main monitoring loop"""
        logger.debug("Clipboard monitoring loop started")
        
        while not self.stop_event.wait(0.5):  # Check every 500ms
            try:
                self._check_clipboard_change()
            except Exception as e:
                logger.error(f"Error in clipboard monitor loop: {e}")
                
        logger.debug("Clipboard monitoring loop ended")
        
    def _check_clipboard_change(self) -> None:
        """Check for clipboard changes and process them"""
        try:
            current_text = self.clipboard_impl.get_text()
            
            if current_text is None:
                return
                
            # Calculate hash of current clipboard content
            current_hash = hashlib.md5(current_text.encode('utf-8')).hexdigest()
            
            # Check if clipboard content has changed
            if current_hash != self.last_clipboard_hash:
                self.last_clipboard_hash = current_hash
                self._process_clipboard_change(current_text)
                
        except Exception as e:
            logger.error(f"Error checking clipboard change: {e}")
            
    def _process_clipboard_change(self, content: str) -> None:
        """Process a detected clipboard change"""
        logger.debug(f"Clipboard changed - content length: {len(content)}")
        
        # Add to history
        clipboard_entry = {
            'timestamp': time.time(),
            'content': content,
            'length': len(content),
            'hash': self.last_clipboard_hash
        }
        self.clipboard_history.append(clipboard_entry)
        
        # Maintain history size
        if len(self.clipboard_history) > self.max_history:
            self.clipboard_history.pop(0)
            
        # Determine if this is likely an LLM-related action
        is_llm_context = self._detect_llm_context(content)
        
        # Only create events for significant clipboard changes
        if len(content) >= Config.CLIPBOARD_THRESHOLD or is_llm_context:
            event = self.create_event(
                action_type="copy",
                file_path=None,
                file_size=len(content),
                action_source=self._get_active_application(),
                target_source="clipboard",
                hu_per=self._calculate_human_percentage(content)
            )
            
            self.event_queue.add_event(event)
            logger.info(f"Clipboard event created - LLM context: {is_llm_context}, size: {len(content)}")
            
    def _detect_llm_context(self, content: str) -> bool:
        """Detect if clipboard content is likely from LLM interaction"""
        # Check content characteristics that suggest LLM output
        llm_indicators = [
            len(content) > 1000,  # Large text blocks
            content.count('\n') > 10,  # Multi-paragraph text
            any(phrase in content.lower() for phrase in [
                'as an ai', 'i cannot', 'i apologize', 'here is',
                'based on', 'in conclusion', 'furthermore', 'however',
                'code:', '```', 'steps:', 'example:'
            ]),
            # Check if previous clipboard was a question/prompt
            self._was_previous_clipboard_prompt()
        ]
        
        return any(llm_indicators)
        
    def _was_previous_clipboard_prompt(self) -> bool:
        """Check if previous clipboard content looks like a prompt"""
        if len(self.clipboard_history) < 2:
            return False
            
        prev_content = self.clipboard_history[-2]['content'].lower()
        prompt_indicators = [
            prev_content.endswith('?'),
            any(word in prev_content for word in [
                'write', 'create', 'generate', 'explain', 'help',
                'how to', 'what is', 'can you'
            ])
        ]
        
        return any(prompt_indicators)
        
    def _get_active_application(self) -> Optional[str]:
        """Get the currently active application (cross-platform)"""
        try:
            system = platform.system()
            
            if system == "Darwin":  # macOS
                return self._get_active_app_macos()
            elif system == "Linux":
                return self._get_active_app_linux()
            elif system == "Windows":
                return self._get_active_app_windows()
            else:
                return "unknown"
                
        except Exception as e:
            logger.debug(f"Could not get active application: {e}")
            return "unknown"
            
    def _get_active_app_macos(self) -> Optional[str]:
        """Get active application on macOS"""
        try:
            from AppKit import NSWorkspace
            workspace = NSWorkspace.sharedWorkspace()
            active_app = workspace.activeApplication()
            return active_app.get('NSApplicationName', 'unknown')
        except ImportError:
            # Fallback to AppleScript if AppKit not available
            import subprocess
            try:
                result = subprocess.run([
                    'osascript', '-e', 
                    'tell application "System Events" to get name of first application process whose frontmost is true'
                ], capture_output=True, text=True, timeout=2)
                return result.stdout.strip() if result.returncode == 0 else "unknown"
            except Exception:
                return "unknown"
        except Exception:
            return "unknown"
            
    def _get_active_app_linux(self) -> Optional[str]:
        """Get active application on Linux"""
        try:
            import subprocess
            # Try xdotool first
            result = subprocess.run(['xdotool', 'getactivewindow', 'getwindowname'], 
                                  capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                return result.stdout.strip()
                
            # Fallback to wmctrl
            result = subprocess.run(['wmctrl', '-a', ':ACTIVE:'], 
                                  capture_output=True, text=True, timeout=2)
            if result.returncode == 0:
                return "linux-window"
                
        except Exception:
            pass
        return "unknown"
        
    def _get_active_app_windows(self) -> Optional[str]:
        """Get active application on Windows"""
        try:
            import win32gui
            import win32process
            import psutil
            
            hwnd = win32gui.GetForegroundWindow()
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            process = psutil.Process(pid)
            return process.name()
        except Exception:
            return "unknown"
            
    def _calculate_human_percentage(self, content: str) -> int:
        """Calculate estimated percentage of human input"""
        # Simple heuristic based on content characteristics
        human_indicators = 0
        total_indicators = 5
        
        # Check for human typing patterns
        if any(char in content for char in ['typo', 'hmm', 'uh', 'ok']):
            human_indicators += 1
            
        # Check for informal language
        if any(word in content.lower() for word in ['lol', 'btw', 'omg', 'yeah']):
            human_indicators += 1
            
        # Check for incomplete thoughts (trailing periods, dashes)
        if content.endswith(('...', '--', ':')):
            human_indicators += 1
            
        # Check for questions
        if '?' in content:
            human_indicators += 1
            
        # Check for short length (more likely human)
        if len(content) < 100:
            human_indicators += 1
            
        return int((human_indicators / total_indicators) * 100)
