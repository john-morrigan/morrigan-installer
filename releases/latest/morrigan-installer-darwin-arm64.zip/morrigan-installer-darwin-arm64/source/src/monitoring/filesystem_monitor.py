import time
import threading
from typing import Dict, Any, Set
from pathlib import Path

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent

from .base_monitor import BaseMonitor
from ..config import Config
from ..logger import get_logger

logger = get_logger(__name__)


class FileSystemMonitor(BaseMonitor):
    """Cross-platform file system monitor"""
    
    def __init__(self, event_queue):
        super().__init__("FileSystemMonitor")
        self.event_queue = event_queue
        self.observer = Observer()
        self.monitored_paths = Config.get_monitored_paths()
        self.file_handlers: Dict[str, FileSystemEventHandler] = {}
        
        # Track recent events to avoid duplicates
        self.recent_events: Set[str] = set()
        self.event_cleanup_thread = None
        
    def start_monitoring(self) -> None:
        """Start file system monitoring"""
        if self.running:
            logger.warning("File system monitor already running")
            return
            
        self.running = True
        
        # Set up handlers for each monitored path
        for path in self.monitored_paths:
            if path.exists() and path.is_dir():
                handler = MorriganFileHandler(self)
                self.file_handlers[str(path)] = handler
                self.observer.schedule(handler, str(path), recursive=True)
                logger.info(f"Monitoring file system path: {path}")
            else:
                logger.warning(f"Monitored path does not exist: {path}")
                
        if self.file_handlers:
            self.observer.start()
            
            # Start cleanup thread for recent events
            self.event_cleanup_thread = threading.Thread(
                target=self._cleanup_recent_events, daemon=True
            )
            self.event_cleanup_thread.start()
            
            logger.info("File system monitoring started")
        else:
            logger.error("No valid paths to monitor")
            self.running = False
            
    def stop_monitoring(self) -> None:
        """Stop file system monitoring"""
        if not self.running:
            return
            
        self.running = False
        
        if self.observer.is_alive():
            self.observer.stop()
            self.observer.join(timeout=5)
            
        logger.info("File system monitoring stopped")
        
    def _cleanup_recent_events(self) -> None:
        """Clean up old event tracking to prevent memory leaks"""
        while self.running:
            time.sleep(60)  # Clean up every minute
            # Events older than 5 seconds are removed
            current_time = time.time()
            to_remove = []
            for event_key in self.recent_events:
                try:
                    # Extract timestamp from event key
                    timestamp = float(event_key.split('|')[-1])
                    if current_time - timestamp > 5:
                        to_remove.append(event_key)
                except (ValueError, IndexError):
                    to_remove.append(event_key)  # Remove malformed keys
                    
            for key in to_remove:
                self.recent_events.discard(key)
                
    def handle_file_event(self, event: FileSystemEvent) -> None:
        """Handle a file system event"""
        try:
            # Create unique event key to avoid duplicates
            event_key = f"{event.event_type}|{event.src_path}|{time.time():.2f}"
            
            if event_key in self.recent_events:
                return  # Duplicate event
                
            self.recent_events.add(event_key)
            
            # Filter events
            if not self._should_process_event(event):
                return
                
            file_path = Path(event.src_path)
            
            # Determine action type
            action_type = self._map_event_to_action(event.event_type)
            
            # Get file size
            file_size = 0
            try:
                if file_path.exists() and file_path.is_file():
                    file_size = file_path.stat().st_size
            except Exception:
                pass
                
            # Determine if this might be LLM-related
            is_large_file = file_size > Config.LARGE_FILE_THRESHOLD
            is_text_file = self._is_text_file(file_path)
            
            # Create event for significant file operations
            if is_large_file or is_text_file or action_type in ["download", "upload"]:
                event_obj = self.create_event(
                    action_type=action_type,
                    file_path=str(file_path),
                    file_size=file_size,
                    action_source=self._detect_source_application(file_path),
                    target_source=str(file_path.parent),
                    hu_per=self._estimate_human_percentage(event, file_path)
                )
                
                self.event_queue.add_event(event_obj)
                logger.info(f"File system event: {action_type} - {file_path.name} ({file_size} bytes)")
                
        except Exception as e:
            logger.error(f"Error handling file event: {e}")
            
    def _should_process_event(self, event: FileSystemEvent) -> bool:
        """Determine if we should process this file system event"""
        # Skip directory events
        if event.is_directory:
            return False
            
        file_path = Path(event.src_path)
        
        # Skip temporary and system files
        skip_patterns = [
            '.tmp', '.temp', '.swp', '.swo', '.lock',
            '~$', '.DS_Store', 'Thumbs.db', '.git/',
            '__pycache__/', '.pyc'
        ]
        
        file_str = str(file_path).lower()
        if any(pattern in file_str for pattern in skip_patterns):
            return False
            
        # Skip very frequent events
        if event.event_type in ['modified'] and self._is_frequent_file(file_path):
            return False
            
        return True
        
    def _is_frequent_file(self, file_path: Path) -> bool:
        """Check if this is a file that changes very frequently"""
        frequent_patterns = [
            '.log', '.cache', '.pid', '.sock'
        ]
        return any(pattern in str(file_path).lower() for pattern in frequent_patterns)
        
    def _map_event_to_action(self, event_type: str) -> str:
        """Map file system event type to action type"""
        mapping = {
            'created': 'create',
            'modified': 'save',
            'moved': 'save',
            'deleted': 'delete'
        }
        return mapping.get(event_type, 'unknown')
        
    def _is_text_file(self, file_path: Path) -> bool:
        """Check if file is likely a text file that might contain LLM content"""
        text_extensions = {
            '.txt', '.md', '.py', '.js', '.html', '.css', '.json',
            '.xml', '.yaml', '.yml', '.csv', '.log', '.sql',
            '.sh', '.bat', '.ps1', '.php', '.rb', '.go', '.rs'
        }
        return file_path.suffix.lower() in text_extensions
        
    def _detect_source_application(self, file_path: Path) -> str:
        """Try to detect which application created/modified the file"""
        # This is a simplified detection - could be enhanced
        parent_dir = file_path.parent.name.lower()
        
        if 'download' in parent_dir:
            return 'browser'
        elif 'desktop' in parent_dir:
            return 'user'
        elif 'documents' in parent_dir:
            return 'office_app'
        else:
            return 'unknown'
            
    def _estimate_human_percentage(self, event: FileSystemEvent, file_path: Path) -> int:
        """Estimate percentage of human involvement in this file operation"""
        human_indicators = 0
        total_indicators = 4
        
        # File created in typical user directories
        if any(folder in str(file_path).lower() for folder in ['desktop', 'documents']):
            human_indicators += 1
            
        # Interactive file types
        if self._is_text_file(file_path):
            human_indicators += 1
            
        # Manual file operations (created/moved vs auto-save)
        if event.event_type in ['created', 'moved']:
            human_indicators += 1
            
        # Files with human-like names
        if any(char in file_path.stem for char in [' ', '_', '-']) and len(file_path.stem) > 3:
            human_indicators += 1
            
        return int((human_indicators / total_indicators) * 100)


class MorriganFileHandler(FileSystemEventHandler):
    """File system event handler for Morrigan monitoring"""
    
    def __init__(self, monitor: FileSystemMonitor):
        self.monitor = monitor
        
    def on_any_event(self, event: FileSystemEvent):
        """Handle any file system event"""
        self.monitor.handle_file_event(event)
