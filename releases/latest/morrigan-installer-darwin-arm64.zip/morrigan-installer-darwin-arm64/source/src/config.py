import os
import platform
from typing import List, Set, Optional
from pathlib import Path

try:
    from dotenv import load_dotenv
    
    # Try to load .env from multiple locations
    env_paths = [
        Path.cwd() / ".env",  # Current directory
        Path(__file__).parent.parent / ".env",  # Project root
        Path("/opt/morrigan/.env") if platform.system() != "Windows" else Path("C:/Program Files/Morrigan/.env"),  # Installation directory
    ]
    
    env_loaded = False
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path)
            env_loaded = True
            break
    
    if not env_loaded:
        # Try default location as fallback
        load_dotenv()
        
except ImportError:
    pass


class Config:

    IS_WINDOWS = platform.system() == "Windows"
    IS_DEVELOPMENT = os.getenv("ENV", "production") == "development"
    API_BASE_URL = os.getenv("API_URL", "https://morrigan-poc-serverless.azurewebsites.net/api")

    # Support both API_KEY and API_TOKEN for backward compatibility
    API_KEY = os.getenv("API_KEY") or os.getenv("API_TOKEN") or ""

    API_TIMEOUT = 30
    if IS_WINDOWS:
        ENDPOINT_ID_PATH = Path("C:/ProgramData/Morrigan/endpoint_id.txt")
        DATA_DIR = Path("C:/ProgramData/Morrigan")
    else:
        ENDPOINT_ID_PATH = Path.home() / ".morrigan" / "endpoint_id.txt"
        DATA_DIR = Path.home() / ".morrigan"
    DATABASE_PATH = DATA_DIR / "events.db"
    MAX_QUEUE_SIZE = 100
    MAX_QUEUE_SIZE_MB = 10
    CLIPBOARD_THRESHOLD = 300
    LARGE_FILE_THRESHOLD = 1024 * 1024
    # FYI Windows only
    MONITORED_PATHS = [
        "~/Desktop",
        "~/Documents",
        "~/Downloads"
    ] if not IS_WINDOWS else [
        "C:/Users/{username}/Desktop",
        "C:/Users/{username}/Documents",
        "C:/Users/{username}/Downloads"
    ]

    LLM_DOMAINS: Set[str] = {
        "chat.openai.com",
        "copilot.microsoft.com",
        "bard.google.com",
        "claude.ai",
        "github.com",
        "gemini.google.com",
        "poe.com",
        "perplexity.ai",
        "character.ai"
    }

    ACTION_TYPES = {
        "copy": "Copy",
        "paste": "Paste",
        "download": "Download",
        "upload": "Upload",
        "create": "Create",
        "save": "Save"
    }
    BATCH_SIZE = 50
    BATCH_TIMEOUT = 24 * 60 * 60

    RETRY_INITIAL_DELAY = 5
    RETRY_MAX_DELAY = 15 * 60
    RETRY_MULTIPLIER = 2
    RETRY_MAX_ATTEMPTS = 10

    IS_PRODUCTION = os.getenv("MORRIGAN_MODE", "production") == "production"
    SILENT_MODE = IS_PRODUCTION or os.getenv("MORRIGAN_SILENT", "false").lower() == "true"
    AUTO_START = IS_PRODUCTION or os.getenv("MORRIGAN_AUTO_START", "false").lower() == "true"

    LOG_LEVEL = "ERROR" if IS_PRODUCTION else os.getenv("LOG_LEVEL", "INFO")
    LOG_TO_CONSOLE = not SILENT_MODE

    LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE = DATA_DIR / "morrigan.log"

    @classmethod
    def ensure_data_directory(cls) -> None:
        cls.DATA_DIR.mkdir(parents=True, exist_ok=True)

    @classmethod
    def get_monitored_paths(cls, username: Optional[str] = None) -> List[Path]:
        if not cls.IS_WINDOWS:
            return [Path(path).expanduser() for path in cls.MONITORED_PATHS]

        if not username:
            username = os.getenv("USERNAME", "")

        paths = []
        for path_template in cls.MONITORED_PATHS:
            path_str = path_template.format(username=username)
            paths.append(Path(path_str))
        return paths

    @classmethod
    def is_llm_domain(cls, url: str) -> bool:
        if not url:
            return False

        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            for llm_domain in cls.LLM_DOMAINS:
                if domain == llm_domain or domain.endswith(f".{llm_domain}"):
                    return True
            return False
        except Exception:
            return False

    @classmethod
    def validate_config(cls) -> List[str]:
        issues = []

        if not cls.API_KEY:
            issues.append("API_KEY or API_TOKEN environment variable not set or empty")

        if not cls.API_BASE_URL:
            issues.append("API_BASE_URL environment variable not set or empty")

        try:
            from .endpoint import endpoint_manager
            endpoint_id = endpoint_manager.get_endpoint_id()
            if not endpoint_id:
                issues.append("Unable to get or generate endpoint_id")
        except Exception as e:
            issues.append(f"Error accessing endpoint_id: {e}")

        return issues
