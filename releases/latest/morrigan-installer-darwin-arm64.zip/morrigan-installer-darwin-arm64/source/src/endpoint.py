import os
import uuid
from pathlib import Path
from .config import Config
from .logger import get_logger

logger = get_logger(__name__)


class EndpointManager:
    def __init__(self):
        self._endpoint_id = None

    def get_endpoint_id(self) -> str:
        if self._endpoint_id:
            return self._endpoint_id

        env_endpoint_id = os.getenv("ENDPOINT_ID")
        if env_endpoint_id:
            self._endpoint_id = env_endpoint_id.strip()
            logger.info(f"Loaded endpoint ID from environment: {self._endpoint_id}")

            try:
                self._save_endpoint_id()
            except Exception as e:
                logger.warning(f"Could not save endpoint ID to file: {e}")

            return self._endpoint_id

        try:
            if Config.ENDPOINT_ID_PATH.exists():
                self._endpoint_id = Config.ENDPOINT_ID_PATH.read_text().strip()
                logger.info(f"Loaded existing endpoint ID from file: {self._endpoint_id}")
                return self._endpoint_id
        except Exception as e:
            logger.warning(f"Could not load existing endpoint ID from file: {e}")

        self._endpoint_id = str(uuid.uuid4())
        logger.info(f"Generated new endpoint ID: {self._endpoint_id}")

        try:
            self._save_endpoint_id()
        except Exception as e:
            logger.error(f"Could not save endpoint ID: {e}")

        return self._endpoint_id

    def _save_endpoint_id(self) -> None:
        Config.ENDPOINT_ID_PATH.parent.mkdir(parents=True, exist_ok=True)

        Config.ENDPOINT_ID_PATH.write_text(self._endpoint_id)
        logger.debug(f"Saved endpoint ID to {Config.ENDPOINT_ID_PATH}")

    def regenerate_endpoint_id(self) -> str:
        self._endpoint_id = str(uuid.uuid4())
        logger.info(f"Regenerated endpoint ID: {self._endpoint_id}")

        try:
            self._save_endpoint_id()
        except Exception as e:
            logger.error(f"Could not save new endpoint ID: {e}")

        return self._endpoint_id


endpoint_manager = EndpointManager()
