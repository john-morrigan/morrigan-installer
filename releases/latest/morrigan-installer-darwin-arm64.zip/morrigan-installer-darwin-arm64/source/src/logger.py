import logging
import logging.handlers
import sys
from .config import Config


def setup_logging() -> logging.Logger:
    Config.ensure_data_directory()

    logger = logging.getLogger("morrigan")
    logger.setLevel(getattr(logging, Config.LOG_LEVEL))

    logger.handlers.clear()

    formatter = logging.Formatter(Config.LOG_FORMAT)

    if Config.LOG_TO_CONSOLE:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    try:
        file_handler = logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10*1024*1024,
            backupCount=5
        )
        file_handler.setLevel(getattr(logging, Config.LOG_LEVEL))
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        logger.warning(f"Could not setup file logging: {e}")

    return logger


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"morrigan.{name}")


setup_logging()
