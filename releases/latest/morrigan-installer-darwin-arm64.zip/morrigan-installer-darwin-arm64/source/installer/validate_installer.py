#!/usr/bin/env python3
"""
Final validation script for the Morrigan cross-platform installer system
"""

import sys
import os
from pathlib import Path


def check_file_exists(file_path, description):
    """Check if a file exists and report status"""
    if file_path.exists():
        print(f"✅ {description}: {file_path}")
        return True
    else:
        print(f"❌ Missing {description}: {file_path}")
        return False


def check_python_syntax(file_path):
    """Check if a Python file has valid syntax"""
    try:
        with open(file_path, 'r') as f:
            compile(f.read(), file_path, 'exec')
        return True
    except SyntaxError as e:
        print(f"❌ Syntax error in {file_path}: {e}")
        return False
    except Exception as e:
        print(f"⚠️  Could not check syntax of {file_path}: {e}")
        return True  # Don't fail for other errors


def validate_installer_system():
    """Validate the complete installer system"""
    print("Morrigan Cross-Platform Installer - System Validation")
    print("=" * 60)
    
    project_dir = Path(__file__).parent
    installer_dir = project_dir / "installer"
    success = True
    
    # Check if installer directory exists
    if not installer_dir.exists():
        print("❌ Installer directory not found!")
        return False
    
    print(f"✅ Installer directory: {installer_dir}")
    
    # Core installer files
    core_files = [
        (installer_dir / "install.py", "Main installer script"),
        (installer_dir / "build_installer.py", "Build script"),
        (installer_dir / "build_installer.sh", "Unix build script"),
        (installer_dir / "build_installer.bat", "Windows build script"),
        (installer_dir / "installer_requirements.txt", "Installer requirements"),
    ]
    
    print("\n📁 Core Installer Files:")
    for file_path, description in core_files:
        if not check_file_exists(file_path, description):
            success = False
    
    # Documentation files
    doc_files = [
        (installer_dir / "INSTALLER_README.md", "Installer documentation"),
        (installer_dir / "IMPLEMENTATION_SUMMARY.md", "Implementation summary"),
        (installer_dir / "QUICK_START.md", "Quick start guide"),
    ]
    
    print("\n📚 Documentation:")
    for file_path, description in doc_files:
        if not check_file_exists(file_path, description):
            success = False
    
    # Test files
    test_files = [
        (installer_dir / "test_installer.py", "Installer test suite"),
        (installer_dir / "test_console_installer.py", "Console installer test"),
    ]
    
    print("\n🧪 Test Files:")
    for file_path, description in test_files:
        if not check_file_exists(file_path, description):
            success = False
    
    # Check Python syntax
    python_files = [f[0] for f in core_files + test_files if f[0].suffix == '.py']
    
    print("\n🐍 Python Syntax Validation:")
    for file_path in python_files:
        if file_path.exists():
            if check_python_syntax(file_path):
                print(f"✅ Syntax OK: {file_path.name}")
            else:
                success = False
    
    # Check script permissions (Unix)
    if os.name != 'nt':  # Not Windows
        script_files = [
            installer_dir / "build_installer.sh"
        ]
        
        print("\n🔒 Script Permissions (Unix):")
        for script in script_files:
            if script.exists():
                if os.access(script, os.X_OK):
                    print(f"✅ Executable: {script.name}")
                else:
                    print(f"⚠️  Not executable: {script.name} (run: chmod +x {script})")
    
    # Check application files
    app_files = [
        (project_dir / "main.py", "Main application"),
        (project_dir / "requirements.txt", "Application requirements"),
        (project_dir / "src" / "config.py", "Configuration module"),
        (project_dir / "src" / "logger.py", "Logger module"),
    ]
    
    print("\n🔧 Application Files:")
    for file_path, description in app_files:
        if not check_file_exists(file_path, description):
            print(f"⚠️  {description} not found - needed for installation")
    
    # Test installer import
    print("\n🏗️  Installer Import Test:")
    try:
        sys.path.insert(0, str(installer_dir))
        
        # Test install.py import
        import importlib.util
        spec = importlib.util.spec_from_file_location("install", installer_dir / "install.py")
        install_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(install_module)
        
        installer = install_module.MorriganInstaller()
        print(f"✅ Installer class imported successfully")
        print(f"✅ Platform detected: {installer.platform}")
        print(f"✅ tkinter available: {getattr(install_module, 'TKINTER_AVAILABLE', 'Unknown')}")
        
    except Exception as e:
        print(f"❌ Installer import failed: {e}")
        success = False
    
    # Summary
    print("\n" + "=" * 60)
    if success:
        print("🎉 VALIDATION PASSED!")
        print("\nYour cross-platform installer system is ready!")
        print("\nNext steps:")
        print("1. Build installer executables:")
        print("   • Windows: installer\\build_installer.bat")
        print("   • macOS/Linux: ./installer/build_installer.sh")
        print("2. Test the installer on target platforms")
        print("3. Distribute installer packages to users")
        print("\nUsers will be able to:")
        print("• Download and run the installer")
        print("• Enter their API credentials during installation")
        print("• Have the monitoring system installed and auto-started")
        print("• No manual configuration required!")
    else:
        print("❌ VALIDATION FAILED!")
        print("\nPlease fix the issues above before proceeding.")
        return False
    
    return True


def main():
    """Main validation function"""
    try:
        return 0 if validate_installer_system() else 1
    except KeyboardInterrupt:
        print("\n\n⏹️  Validation interrupted by user")
        return 1
    except Exception as e:
        print(f"\n\n💥 Validation error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
