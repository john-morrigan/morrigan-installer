# Quick Start Guide - Morrigan Cross-Platform Installer

## For Software Distributors

### 1. Build the Installer

**Windows:**
```cmd
build_installer.bat
```

**macOS/Linux:**
```bash
./build_installer.sh
```

This creates:
- Standalone installer executable
- Distribution ZIP packages in `dist/` folder

### 2. Distribute to Users

Upload the ZIP files from `dist/` to your distribution platform. Users download the appropriate package for their operating system.

## For End Users

### 1. Download and Extract

Download the installer package for your platform and extract the ZIP file.

### 2. Run the Installer

**Windows:**
- Right-click `MorriganInstaller.exe`
- Select "Run as administrator"

**macOS:**
```bash
sudo ./MorriganInstaller
```

**Linux:**
```bash
sudo ./MorriganInstaller
```

### 3. Enter Credentials

The installer will prompt you for:
- **API URL** (usually pre-filled)
- **API Key** (required - your authentication token)
- **Endpoint ID** (optional - auto-generated if empty)

### 4. Choose Options

Select your preferences:
- ✅ Start automatically on system boot (recommended)
- ✅ Create desktop shortcuts

### 5. Installation Complete

The installer will:
- Install the monitoring system
- Configure auto-start service
- Create shortcuts
- Start monitoring immediately

**No additional configuration needed!**

## What Gets Installed

### Windows
- **Program**: `C:\Program Files\Morrigan\`
- **Data**: `C:\ProgramData\Morrigan\`
- **Auto-start**: Windows Startup folder
- **Uninstaller**: `C:\Program Files\Morrigan\uninstall.bat`

### macOS
- **Program**: `/opt/morrigan/`
- **Data**: `~/.morrigan/`
- **Auto-start**: LaunchAgent service
- **Application**: `/Applications/Morrigan Monitor.app`
- **Uninstaller**: `/opt/morrigan/uninstall.sh`

### Linux
- **Program**: `/opt/morrigan/`
- **Data**: `~/.morrigan/`
- **Auto-start**: systemd service
- **Desktop**: `~/Desktop/morrigan-monitor.desktop`
- **Uninstaller**: `/opt/morrigan/uninstall.sh`

## Troubleshooting

### Common Issues

**"Permission denied"**
→ Run installer as administrator (Windows) or with sudo (macOS/Linux)

**"Python not found"**
→ Install Python 3.8+ from python.org

**GUI not working**
→ Installer automatically falls back to console mode

**Service not starting**
→ Check logs in the data directory for error details

### Getting Help

1. Check the installation logs in the data directory
2. Verify API credentials are correct
3. Try manual installation using the source files included in the ZIP
4. Contact support with log files and system information

## Features

✅ **Cross-Platform**: Works on Windows, macOS, and Linux  
✅ **User-Friendly**: GUI installer with progress tracking  
✅ **Secure**: Prompts for credentials during installation  
✅ **Automatic**: Sets up services and auto-start  
✅ **Complete**: Includes uninstaller and shortcuts  
✅ **Fallback**: Console mode if GUI unavailable  

## Next Steps After Installation

The monitoring system starts automatically and runs in the background. You can:

- **Check Status**: Look for the monitoring process in Task Manager/Activity Monitor
- **View Logs**: Check the log files in the data directory
- **Restart Service**: Use the platform's service management tools
- **Uninstall**: Run the uninstaller script if needed

The system will now monitor your LLM interactions and send anonymized metadata to the configured API endpoint.
