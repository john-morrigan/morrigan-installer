#!/bin/bash
# Morrigan LLM Monitor - Cross-Platform Installer Builder

set -e

echo "Morrigan Cross-Platform Installer Builder"
echo "========================================="

# Navigate to installer directory
cd "$(dirname "$0")"

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    if ! command -v python &> /dev/null; then
        echo "Error: Python is not installed or not in PATH"
        exit 1
    else
        PYTHON_CMD="python"
    fi
else
    PYTHON_CMD="python3"
fi

echo "Using Python: $PYTHON_CMD"

# Check Python version
PYTHON_VERSION=$($PYTHON_CMD -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "Python version: $PYTHON_VERSION"

if $PYTHON_CMD -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)"; then
    echo "✅ Python version is compatible"
else
    echo "❌ Python 3.8 or higher is required"
    exit 1
fi

# Install build dependencies
echo ""
echo "Installing build dependencies..."
$PYTHON_CMD -m pip install --upgrade pip
$PYTHON_CMD -m pip install pyinstaller

# Run the build script
echo ""
echo "Building installer..."
$PYTHON_CMD build_installer.py

echo ""
echo "Build complete! Check the '../dist/' directory for distribution packages."
