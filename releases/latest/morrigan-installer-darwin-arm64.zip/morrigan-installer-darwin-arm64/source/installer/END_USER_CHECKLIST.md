# End User Installation Checklist

## ✅ What You Need Before Starting

### System Requirements
- [ ] **Windows 10+**, **macOS 10.14+**, or **Linux** (Ubuntu 18.04+, etc.)
- [ ] **Python 3.8 or higher** installed
  - Check: Run `python --version` or `python3 --version` in terminal
  - Download from: https://python.org if needed
- [ ] **Administrator privileges** on your computer
- [ ] **Internet connection** (for downloading dependencies)

### Information You'll Need
- [ ] **API URL** (provided by your organization)
- [ ] **API Key** (your authentication token)
- [ ] **Endpoint ID** (optional - can be auto-generated)

---

## 📥 Installation Steps

### 1. Download
- [ ] Download the installer package for your platform:
  - Windows: `morrigan-installer-windows-amd64.zip`
  - macOS: `morrigan-installer-darwin-arm64.zip` (Apple Silicon) or `morrigan-installer-darwin-x86_64.zip` (Intel)
  - Linux: `morrigan-installer-linux-x86_64.zip`

### 2. Extract
- [ ] Extract the ZIP file to your Downloads folder (or anywhere convenient)
- [ ] You should see a file called `MorriganInstaller` (or `MorriganInstaller.exe` on Windows)

### 3. Run Installer
- [ ] **Windows**: Right-click `MorriganInstaller.exe` → Select "Run as administrator"
- [ ] **macOS**: Open Terminal, navigate to extracted folder, run `sudo ./MorriganInstaller`
- [ ] **Linux**: Open Terminal, navigate to extracted folder, run `sudo ./MorriganInstaller`

### 4. Follow Prompts
- [ ] Enter your **API URL** when prompted
- [ ] Enter your **API Key** when prompted
- [ ] Enter **Endpoint ID** (or leave blank to auto-generate)
- [ ] Choose whether to **start automatically on boot** (recommended: Yes)
- [ ] Choose whether to **create desktop shortcuts** (recommended: Yes)

### 5. Installation Complete
- [ ] Wait for installation to finish (usually 1-2 minutes)
- [ ] You should see "Installation completed successfully!" message
- [ ] Monitoring will start automatically

---

## ✅ Verify Installation

### Check if Monitoring is Running
- [ ] **Windows**: Open Task Manager → Look for "python.exe" running Morrigan
- [ ] **macOS**: Open Activity Monitor → Look for "python" running Morrigan
- [ ] **Linux**: Run `ps aux | grep morrigan` in terminal

### Check Logs (if needed)
- [ ] **Windows**: Check `C:\ProgramData\Morrigan\morrigan.log`
- [ ] **macOS/Linux**: Check `~/.morrigan/morrigan.log`

### Test Configuration
- [ ] The system should be sending data to your API endpoint
- [ ] Check with your administrator to confirm data is being received

---

## 🚨 Troubleshooting

### Common Issues

**"Permission denied" error:**
- [ ] Make sure you're running as administrator (Windows) or with `sudo` (macOS/Linux)

**"Python not found" error:**
- [ ] Install Python 3.8+ from https://python.org
- [ ] Make sure Python is added to your system PATH

**GUI doesn't appear:**
- [ ] The installer automatically switches to console mode - this is normal
- [ ] Just follow the text prompts in the terminal

**Installation fails:**
- [ ] Check your internet connection
- [ ] Verify you have enough disk space (needs ~200MB)
- [ ] Try running the installer again

### Getting Help
- [ ] Check the log files mentioned above
- [ ] Contact your IT administrator with:
  - Your operating system and version
  - Any error messages you see
  - The log file contents

---

## 🔄 After Installation

### Normal Operation
- [ ] The monitoring system runs automatically in the background
- [ ] It will start automatically when you boot your computer
- [ ] You don't need to do anything else - it just works!

### If You Need to Restart Monitoring
- [ ] **Windows**: Run the "Morrigan Monitor" shortcut from Start Menu or Desktop
- [ ] **macOS**: Run the "Morrigan Monitor" app from Applications folder
- [ ] **Linux**: Run the desktop shortcut or use: `sudo systemctl start morrigan`

### To Uninstall
- [ ] **Windows**: Run `C:\Program Files\Morrigan\uninstall.bat`
- [ ] **macOS/Linux**: Run `sudo /opt/morrigan/uninstall.sh`

---

## 📞 Support

If you encounter any issues:
1. Check this checklist first
2. Look at the log files for error messages
3. Contact your organization's IT support with the log file and error details

The installation process is designed to be simple - most users complete it in under 5 minutes!
