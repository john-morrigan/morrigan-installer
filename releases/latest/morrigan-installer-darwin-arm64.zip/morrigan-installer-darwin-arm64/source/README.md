# Morrigan LLM Monitoring Client

A Windows service for monitoring LLM interactions and sending anonymized metadata to the Morrigan API.

## Quick Start

### For End Users (Recommended)

**Download and run the cross-platform installer:**

1. **Download** the installer package for your platform from the releases
2. **Extract** the ZIP file
3. **Run the installer**:
   - **Windows**: Right-click `MorriganInstaller.exe` → "Run as administrator"
   - **macOS**: `sudo ./MorriganInstaller`
   - **Linux**: `sudo ./MorriganInstaller`
4. **Enter your API credentials** when prompted
5. **Choose installation options** (auto-start, shortcuts)
6. **Installation completes** - monitoring starts automatically!

**Benefits:**
- ✅ No manual configuration required
- ✅ Works on Windows, macOS, and Linux
- ✅ Secure credential input during installation
- ✅ Auto-starts monitoring immediately
- ✅ Professional installation experience
- ✅ Creates uninstaller for easy removal

### For Developers

For development and testing:

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Configure environment:
   ```bash
   cp .env.example .env
   # Edit .env with your API credentials
   ```
4. Run manually:
   ```bash
   python main.py --real-monitors
   ```

## Building the Installer

### Create Cross-Platform Installer

```bash
# Windows
installer\build_installer.bat

# macOS/Linux
cd installer
chmod +x build_installer.sh
./build_installer.sh
```

This creates:
- Standalone installer executable
- Distribution packages for all platforms
- Complete source backup for manual installation

See `installer/INSTALLER_README.md` for detailed build instructions.

## Configuration

### API Credentials Setup

**🔑 IMPORTANT: Where to Set API Credentials**

**For End Users (Installer Method - Recommended):**
- API credentials are entered during the installation process
- Installer prompts for API URL, API Key, and optional Endpoint ID
- **No manual configuration needed** - installer handles everything
- Credentials are securely stored in the installed system

**For Development:**
```bash
# Copy template and edit with your credentials
cp .env.example .env
# Edit .env with your development API credentials
```

Environment variables:
```
API_URL=https://your-api-endpoint.com/api
API_KEY=your-api-key
ENV=development
```

### Installation Locations

**Windows:**
- Installation: `C:\Program Files\Morrigan\`
- Data/Config: `C:\ProgramData\Morrigan\`
- Logs: `C:\ProgramData\Morrigan\morrigan.log`

**macOS/Linux:**
- Installation: `/opt/morrigan/`
- Data/Config: `~/.morrigan/`
- Logs: `~/.morrigan/morrigan.log`

## Directory Structure

```
morrigan/
├── src/                 # Source code
├── installer/           # Cross-platform installer system
│   ├── install.py       # Main installer script
│   ├── build_installer.py  # Build script
│   ├── *.sh/.bat        # Platform build scripts
│   └── *.md             # Installer documentation
├── docs/               # Documentation
├── demos/              # Demo applications
├── test/               # Unit tests
├── main.py             # Application entry point
└── requirements.txt    # Application dependencies
```
## Commands

### Configuration Check
```bash
python main.py --config-check
```

### Start Monitoring
```bash
python main.py --real-monitors
```

### View Status
```bash
python main.py --status
```

## Development

### Running Tests
```bash
python -m pytest test/
```

### Code Structure
- `src/config.py` - Configuration management
- `src/file_monitor.py` - File system monitoring
- `src/api_client.py` - API communication
- `src/event_logger.py` - Event logging
- `main.py` - Application entry point

## License

This project is proprietary software.

```bash
pip install pipenv
```

2. Install dependencies:
```bash
pipenv install --dev
```

3. Activate virtual environment:
```bash
pipenv shell
```

4. Run tests:
```bash
pytest
```

5. Run integration tests:
```bash
behave
```

## Configuration

Configuration is managed through `src/config.py`. Settings include:
- API endpoint and authentication
- Monitoring thresholds and patterns
- Local storage limits
- Retry policies

Environment variables in .env:
- ENV: development/production mode
- API_URL: Your Morrigan API endpoint
- API_KEY: Authentication key
- LOG_LEVEL: Logging verbosity (DEBUG, INFO, WARNING, ERROR)

## Architecture

- `src/monitoring/` - Monitoring services
  - `real_clipboard_monitor.py` - Clipboard monitoring
  - `filesystem_monitor.py` - File system event detection
  - `window_monitor.py` - Window and browser tracking
  - `llm_detector.py` - AI content detection and analysis
  - `service.py` - Service coordinator
- `src/storage/` - SQLite event queue
- `src/api/` - HTTP client for API communication
- `src/config.py` - Configuration management
- `src/endpoint.py` - Endpoint ID management
- `test/` - Unit and integration tests

## LLM Detection System

The system uses multiple detection methods:
- Content Analysis: AI language patterns, code blocks, prompt detection
- Domain Correlation: LLM service identification (ChatGPT, Claude, etc.)
- Timing Analysis: Interaction pattern recognition
- File Pattern Analysis: AI-generated file detection
- Confidence Scoring: Evidence evaluation

## Event Queue Management

- SQLite local storage
- FIFO queue management with size limits
- Cleanup of sent events
- Batch submission with exponential backoff retry
- Event status tracking (pending, sent, failed)

## Logging and Monitoring

Logs are written to both console and file:
- Real-time monitoring status
- Event detection and processing
- API communication results
- Error tracking and debugging information

Check logs for monitoring activity:
```bash
tail -f logs/morrigan_client.log
```

## Deployment Notes

The service runs as a background process with service integration capabilities.

## Documentation

- `README.md` - Setup, usage, and development guide (this file)
- `docs/DESIGN.md` - System architecture and design decisions
