#!/usr/bin/env python3
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from src.config import Config
from src.logger import get_logger
from src.monitoring.service import MonitoringService
from src.api.client import api_client
from src.endpoint import endpoint_manager

logger = get_logger(__name__)


def parse_args():
    parser = argparse.ArgumentParser(description="Morrigan LLM Monitoring Client")

    parser.add_argument(
        "--config-check",
        action="store_true",
        help="Check configuration and exit"
    )

    parser.add_argument(
        "--test-api",
        action="store_true",
        help="Test API connection and exit"
    )

    parser.add_argument(
        "--real-monitors",
        action="store_true",
        help="Use real monitors (clipboard, file, window) for system monitoring"
    )

    parser.add_argument(
        "--status",
        action="store_true",
        help="Show service status and exit"
    )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging"
    )

    parser.add_argument(
        "--endpoint-id",
        action="store_true",
        help="Show endpoint ID and exit"
    )

    return parser.parse_args()


def check_configuration():
    print("--- Morrigan Configuration Check ---")

    issues = Config.validate_config()
    if issues:
        print("\n❌ Configuration Issues:")
        for issue in issues:
            print(f"  - {issue}")
        return False
    else:
        print("\n✅ Configuration OK")

    print(f"\nAPI URL: {Config.API_BASE_URL}")
    print(f"API Key: {'SET' if Config.API_KEY else 'NOT SET'}")
    
    # Show endpoint ID
    endpoint_id = endpoint_manager.get_endpoint_id()
    print(f"Endpoint ID: {endpoint_id}")
    
    print(f"Data Directory: {Config.DATA_DIR}")
    print(f"Database Path: {Config.DATABASE_PATH}")
    print(f"Environment: {'Development' if Config.IS_DEVELOPMENT else 'Production'}")
    print(f"Platform: {'Windows' if Config.IS_WINDOWS else 'Other'}")

    return len(issues) == 0


def test_api_connection():
    print("--- API Connection Test ---")

    try:
        response = api_client.test_connection()
        if response.success:
            print("API connection successful")
            return True
        else:
            print(f"API connection failed: {response.error}")
            return False
    except Exception as e:
        print(f"API connection error: {e}")
        return False


def show_endpoint_id():
    endpoint_id = endpoint_manager.get_endpoint_id()
    print(f"Endpoint ID: {endpoint_id}")


def show_status():
    print("--- Morrigan Service Status ---")

    print("Service: Not running (use main service to start)")

    show_endpoint_id()

    try:
        from src.storage.event_queue import EventQueue
        queue = EventQueue()
        stats = queue.get_queue_stats()
        print(f"Queue: {stats.get('pending_events', 0)} pending, {stats.get('total_events', 0)} total")
    except Exception as e:
        print(f"Queue: Error accessing ({e})")


def main():
    args = parse_args()

    if args.debug:
        import logging
        logging.getLogger("morrigan").setLevel(logging.DEBUG)

    logger.info("Starting Morrigan Client")

    if args.config_check:
        success = check_configuration()
        sys.exit(0 if success else 1)

    if args.test_api:
        success = test_api_connection()
        sys.exit(0 if success else 1)

    if args.status:
        show_status()
        sys.exit(0)

    if args.endpoint_id:
        show_endpoint_id()
        sys.exit(0)

    if not check_configuration():
        logger.error("Configuration check failed. Use --config-check for details.")
        sys.exit(1)

    service = MonitoringService()

    if args.real_monitors:
        logger.info("Starting with real cross-platform monitors")
        service.create_real_monitors()
    else:
        logger.info("Starting with real cross-platform monitors (default)")
        service.create_real_monitors()

    try:
        service.run()
    except Exception as e:
        logger.error(f"Service error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
