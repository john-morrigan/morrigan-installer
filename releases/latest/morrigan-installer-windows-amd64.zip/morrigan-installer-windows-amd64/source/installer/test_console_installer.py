#!/usr/bin/env python3
"""
Simple test for the console installer functionality
"""

import sys
from pathlib import Path

def test_console_installer():
    """Test console installer without GUI dependencies"""
    print("Testing console installer functionality...")
    
    # Add the installer directory to Python path
    installer_dir = Path(__file__).parent
    sys.path.insert(0, str(installer_dir))
    
    try:
        # Import the installer module
        import install
        
        print("✅ Installer module imported successfully")
        print(f"✅ tkinter available: {install.TKINTER_AVAILABLE}")
        
        # Create installer instance
        installer = install.MorriganInstaller()
        print(f"✅ Installer created for platform: {installer.platform}")
        print(f"✅ Install directory: {installer.install_dir}")
        print(f"✅ Data directory: {installer.data_dir}")
        print(f"✅ Source directory: {installer.source_dir}")
        
        # Test configuration
        test_config = {
            "api_url": "https://test.example.com/api",
            "api_key": "test-key-123",
            "endpoint_id": "test-endpoint",
            "auto_start": True,
            "create_shortcut": True
        }
        
        installer.config = test_config
        print("✅ Configuration set successfully")
        
        # Test that we can run console installer function
        print("✅ Console installer function available")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    print("Morrigan Console Installer Test")
    print("=" * 40)
    
    if test_console_installer():
        print("\n🎉 Console installer test passed!")
        print("\nThe installer should work in console mode even without GUI support.")
        print("To test the full installer, run: python install.py --console")
    else:
        print("\n❌ Console installer test failed!")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
