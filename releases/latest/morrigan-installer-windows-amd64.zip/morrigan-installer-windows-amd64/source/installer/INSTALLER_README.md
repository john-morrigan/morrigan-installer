# Morrigan Cross-Platform Installer

This directory contains the cross-platform installer system for the Morrigan LLM Monitor. The installer creates a standalone executable that prompts users for their API credentials and automatically installs the monitoring system.

## Quick Start

### For Distribution (Building the Installer)

1. **Windows**:
   ```cmd
   build_installer.bat
   ```

2. **macOS/Linux**:
   ```bash
   chmod +x build_installer.sh
   ./build_installer.sh
   ```

This creates:
- A standalone installer executable (`MorriganInstaller.exe` on Windows, `MorriganInstaller` on Unix)
- A distribution ZIP file in the `dist/` directory containing the installer and source files

### For End Users (Using the Installer)

1. **Download** the appropriate distribution package for your platform
2. **Extract** the ZIP file
3. **Run the installer**:
   
   **Windows**:
   - Right-click `MorriganInstaller.exe` → "Run as administrator"
   
   **macOS**:
   ```bash
   sudo ./MorriganInstaller
   ```
   
   **Linux**:
   ```bash
   sudo ./MorriganInstaller
   ```

4. **Follow the prompts** to enter your API credentials
5. **Choose installation options** (auto-start, shortcuts, etc.)
6. **Installation completes** - monitoring starts automatically!

## Installation Process

The installer performs these steps:

1. **System Requirements Check**: Verifies Python 3.8+ and admin privileges
2. **Directory Creation**: Creates installation and data directories
3. **File Installation**: Copies application files to the system
4. **Configuration**: Creates `.env` file with user credentials
5. **Dependencies**: Installs Python requirements
6. **Service Setup**: Configures auto-start (Windows Task Scheduler, macOS LaunchAgent, Linux systemd)
7. **Shortcuts**: Creates desktop and start menu shortcuts
8. **Finalization**: Sets permissions and creates uninstaller

## Installation Locations

### Windows
- **Program Files**: `C:\Program Files\Morrigan\`
- **Data Directory**: `C:\ProgramData\Morrigan\`
- **Auto-start**: Windows Startup folder
- **Shortcuts**: Desktop and Start Menu

### macOS
- **Program Files**: `/opt/morrigan/`
- **Data Directory**: `~/.morrigan/`
- **Auto-start**: LaunchAgent (`~/Library/LaunchAgents/`)
- **Shortcuts**: Applications folder

### Linux
- **Program Files**: `/opt/morrigan/`
- **Data Directory**: `~/.morrigan/`
- **Auto-start**: systemd service
- **Shortcuts**: Desktop and Applications menu

## User Experience

### GUI Mode (Default)
- Modern, user-friendly interface using tkinter
- Clear prompts for API credentials
- Installation progress bar
- Configuration options checkboxes
- Success/error messages

### Console Mode (Fallback)
- Text-based interface for headless systems
- Same functionality as GUI mode
- Use `--console` flag to force console mode

### Credentials Required
- **API URL**: Morrigan API endpoint (pre-filled with default)
- **API Key**: User's authentication token (required)
- **Endpoint ID**: Optional unique identifier (auto-generated if empty)

## Features

### Cross-Platform Support
- ✅ Windows (7, 8, 10, 11)
- ✅ macOS (10.14+)
- ✅ Linux (Ubuntu, Debian, CentOS, etc.)

### Installation Options
- ✅ Auto-start on system boot
- ✅ Desktop shortcuts
- ✅ Start menu/Applications integration
- ✅ System service registration

### Security
- ✅ Requires admin/sudo privileges for system installation
- ✅ Credentials stored securely in configuration files
- ✅ No hardcoded credentials in source code

### User-Friendly
- ✅ Single executable - no Python knowledge required
- ✅ Automatic dependency installation
- ✅ Clear error messages and validation
- ✅ Uninstaller creation

## Building the Installer

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- Internet connection (for PyInstaller download)

### Build Process

The build script (`build_installer.py`) performs:

1. **Dependency Check**: Installs PyInstaller if not present
2. **Executable Creation**: Uses PyInstaller to create standalone executable
3. **Distribution Package**: Creates ZIP with installer + source files
4. **Documentation**: Includes installation instructions

### Build Outputs

```
dist/
└── morrigan-installer-{platform}-{arch}/
    ├── MorriganInstaller(.exe)     # Standalone installer
    ├── source/                     # Backup source files
    │   ├── main.py
    │   ├── requirements.txt
    │   ├── src/
    │   └── ...
    └── INSTALL.md                  # User instructions
```

## Development

### Testing the Installer

1. **Build installer**: Run `build_installer.sh/.bat`
2. **Test installation**: Run the created executable
3. **Verify installation**: Check installed files and services
4. **Test monitoring**: Confirm monitoring service starts
5. **Test uninstaller**: Run uninstall script

### Customization

Key files to modify:

- `install.py`: Main installer logic and GUI
- `build_installer.py`: Build process and packaging
- `installer_requirements.txt`: Installer dependencies

### Adding Features

The installer system is modular:

- **GUI Updates**: Modify the tkinter interface in `install.py`
- **Platform Support**: Add platform-specific methods
- **Service Integration**: Extend `_setup_*_service()` methods
- **Configuration**: Update config creation and validation

## Troubleshooting

### Common Issues

**"Permission denied" errors**:
- Run installer as administrator (Windows) or with sudo (Unix)

**"Python not found" errors**:
- Install Python 3.8+ from python.org
- Ensure Python is in system PATH

**GUI not available**:
- Installer falls back to console mode automatically
- Use `--console` flag to force console mode

**Service not starting**:
- Check logs in data directory
- Verify API credentials are correct
- Ensure firewall allows outbound connections

### Log Locations

- **Windows**: `C:\ProgramData\Morrigan\morrigan.log`
- **macOS/Linux**: `~/.morrigan/morrigan.log`

### Uninstallation

Automatic uninstallers are created:

- **Windows**: `C:\Program Files\Morrigan\uninstall.bat`
- **macOS/Linux**: `/opt/morrigan/uninstall.sh`

## Distribution

### For Software Vendors

1. **Build installers** for each target platform
2. **Upload distribution packages** to download server
3. **Provide download links** to users
4. **Include installation instructions**

### For End Users

1. **Download** appropriate package for your OS
2. **Extract** and run installer
3. **Enter API credentials** when prompted
4. **Monitoring starts automatically**

The installer handles all technical details - users just need their API credentials!

## Support

For technical issues:

1. Check the installation logs
2. Verify system requirements
3. Try manual installation using source files
4. Contact support with log files and system information

---

This installer system replaces the previous Windows-only MSI approach with a truly cross-platform solution that works on Windows, macOS, and Linux systems.
