# What End Users Need - Morrigan Installation Guide

## 🎯 **For End Users (Simplest Method)**

### What You Download
End users only need **ONE FILE** - the distribution package for their platform:

**Download Options:**
- `morrigan-installer-windows-amd64.zip` (Windows)
- `morrigan-installer-darwin-arm64.zip` (macOS Apple Silicon)
- `morrigan-installer-darwin-x86_64.zip` (macOS Intel)
- `morrigan-installer-linux-x86_64.zip` (Linux)

### What's Inside the ZIP
```
morrigan-installer-{platform}-{arch}/
├── MorriganInstaller(.exe)     # 🚀 THE ONLY FILE USERS NEED TO RUN
├── INSTALL.md                  # 📖 Simple installation instructions
└── source/                     # 📁 Backup files (for manual install if needed)
    ├── main.py
    ├── requirements.txt
    ├── src/
    └── installer/
```

### Installation Process
1. **Download** the ZIP file for their platform
2. **Extract** the ZIP file
3. **Run** the installer:
   - **Windows**: Right-click `MorriganInstaller.exe` → "Run as administrator"
   - **macOS**: `sudo ./MorriganInstaller`
   - **Linux**: `sudo ./MorriganInstaller`
4. **Enter credentials** when prompted
5. **Done!** - System is installed and monitoring starts automatically

### What Users Need on Their Machine
- **Python 3.8+** (installer will check and prompt if missing)
- **Admin/sudo privileges** (for system-wide installation)
- **Internet connection** (for downloading dependencies during installation)
- **API credentials** (URL and Key provided by your organization)

---

## 🛠️ **For Software Distributors**

### Files Needed to Create Distribution Packages

**Essential Application Files:**
```
morrigan/
├── main.py                     # Application entry point
├── requirements.txt            # Python dependencies
├── src/                        # Application source code
│   ├── config.py
│   ├── logger.py
│   ├── endpoint.py
│   ├── api/
│   ├── monitoring/
│   └── storage/
└── installer/                  # Installer system
    ├── install.py              # Main installer
    ├── build_installer.py      # Build script
    ├── build_installer.sh      # Unix build script
    ├── build_installer.bat     # Windows build script
    └── installer_requirements.txt
```

### Build Process
1. **Run the build script**:
   ```bash
   # Windows
   installer\build_installer.bat
   
   # macOS/Linux
   cd installer && ./build_installer.sh
   ```

2. **Generated files**:
   ```
   MorriganInstaller(.exe)         # Standalone executable
   dist/                          # Distribution packages
   ├── morrigan-installer-windows-amd64.zip
   ├── morrigan-installer-darwin-arm64.zip
   └── morrigan-installer-linux-x86_64.zip
   ```

3. **Distribute** the ZIP files to users

---

## 📋 **Minimum File Set for Manual Installation**

If the automatic installer doesn't work, users need these files for manual setup:

**Core Files:**
```
morrigan-manual/
├── main.py                 # Application entry point
├── requirements.txt        # Dependencies list
├── .env.example           # Configuration template
└── src/                   # All source code
    ├── config.py
    ├── logger.py
    ├── endpoint.py
    ├── api/
    ├── monitoring/
    └── storage/
```

**Manual Installation Steps:**
1. Install Python 3.8+
2. Copy files to desired location
3. Run: `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and edit with credentials
5. Run: `python main.py --real-monitors`

---

## 🎯 **Summary for Different Users**

### End Users (Non-Technical)
**Need:** Just the ZIP file for their platform
**Steps:** Download → Extract → Run installer → Enter credentials → Done!

### IT Administrators
**Need:** Same ZIP file, but may want to test manual installation
**Benefit:** Can deploy via group policy, script deployment, etc.

### Developers
**Need:** Full source code repository
**Use:** For customization, debugging, or contributing

### Software Distributors
**Need:** Full repository + build environment
**Output:** Creates the ZIP files that end users download

---

## 🔄 **Distribution Workflow**

```
Developer/Distributor:
├── Has full source code
├── Runs build scripts
├── Creates distribution ZIPs
├── Uploads to distribution platform
└── Provides download links

End User:
├── Downloads platform-specific ZIP
├── Extracts and runs installer
├── Enters API credentials
├── Installation completes automatically
└── Monitoring starts immediately
```

## 📁 **File Size Expectations**

- **Distribution ZIP**: ~10-50MB (includes Python dependencies)
- **Installed System**: ~100-200MB (includes all dependencies)
- **Runtime Memory**: ~50-100MB (lightweight monitoring)

The installer is designed to be as simple as possible for end users while providing all necessary files for any installation scenario.
