import time
import hashlib
import psutil
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from pathlib import Path

from ..config import Config
from ..logger import get_logger
from ..endpoint import endpoint_manager
from ..storage.event_queue import Event

logger = get_logger(__name__)


class BaseMonitor(ABC):
    def __init__(self, name: str):
        self.name = name
        self.running = False
        self.last_human_input_time = time.time()
        logger.debug(f"Initialized {name} monitor")

    @abstractmethod
    def start_monitoring(self) -> None:
        pass

    @abstractmethod
    def stop_monitoring(self) -> None:
        pass

    def update_human_input_time(self) -> None:
        self.last_human_input_time = time.time()

    def create_event(
        self,
        action_type: str,
        file_path: Optional[str] = None,
        file_size: int = 0,
        action_source: Optional[str] = None,
        target_source: Optional[str] = None,
        hu_per: int = 0
    ) -> Event:
        now_utc = datetime.now(timezone.utc)
        io_utc = datetime.fromtimestamp(self.last_human_input_time, timezone.utc)

        file_id = self._generate_file_id(file_path) if file_path else "no-file"

        file_type = None
        if file_path:
            file_type = Path(file_path).suffix.lower()

        api_action_type = Config.ACTION_TYPES.get(action_type.lower(), action_type)

        return Event(
            trigger_utc=now_utc.isoformat(),
            io_utc=io_utc.isoformat(),
            utc_zone="UTC",  # Always use UTC for consistency
            endpoint_id=endpoint_manager.get_endpoint_id(),
            file_id=file_id,
            action_type=api_action_type,
            file_type=file_type,
            file_size=file_size,
            action_source=action_source,
            target_source=target_source,
            hu_per=hu_per
        )

    def _generate_file_id(self, file_path: str) -> str:
        try:
            path = Path(file_path)

            if path.exists():
                stat = path.stat()
                content = f"{file_path}:{stat.st_size}:{stat.st_mtime}"
            else:
                content = file_path

            return hashlib.sha256(content.encode()).hexdigest()[:16]

        except Exception as e:
            logger.warning(f"Could not generate file ID for {file_path}: {e}")
            return hashlib.sha256(file_path.encode()).hexdigest()[:16]

    def get_active_window_info(self) -> Dict[str, Optional[str]]:
        try:
            if Config.IS_WINDOWS:
                return self._get_windows_active_window()
            else:
                return self._get_generic_active_window()
        except Exception as e:
            logger.warning(f"Could not get active window info: {e}")
            return {'process_name': None, 'window_title': None}

    def _get_windows_active_window(self) -> Dict[str, Optional[str]]:
        try:
            import win32gui
            import win32process

            hwnd = win32gui.GetForegroundWindow()
            if not hwnd:
                return {'process_name': None, 'window_title': None}

            window_title = win32gui.GetWindowText(hwnd)

            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            process = psutil.Process(pid)
            process_name = process.name()

            return {
                'process_name': process_name,
                'window_title': window_title,
                'pid': pid
            }

        except Exception as e:
            logger.debug(f"Windows window detection failed: {e}")
            return {'process_name': None, 'window_title': None}

    def _get_generic_active_window(self) -> Dict[str, Optional[str]]:
        try:
            browser_processes = []
            for proc in psutil.process_iter(['pid', 'name']):
                name = proc.info['name'].lower()
                if any(browser in name for browser in ['chrome', 'firefox', 'safari', 'edge']):
                    browser_processes.append(proc.info)

            if browser_processes:
                return {
                    'process_name': browser_processes[0]['name'],
                    'window_title': 'Browser Window',
                    'pid': browser_processes[0]['pid']
                }

            return {'process_name': None, 'window_title': None}

        except Exception as e:
            logger.debug(f"Generic window detection failed: {e}")
            return {'process_name': None, 'window_title': None}

    def extract_domain_from_title(self, window_title: str) -> Optional[str]:
        if not window_title:
            return None
        try:
            import re
            domain_pattern = r'(?:https?://)?(?:www\.)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'

            match = re.search(domain_pattern, window_title)
            if match:
                return match.group(1).lower()

            title_lower = window_title.lower()
            for domain in Config.LLM_DOMAINS:
                if domain in title_lower:
                    return domain

            return None

        except Exception as e:
            logger.debug(f"Domain extraction failed: {e}")
            return None

    def is_llm_context(
        self,
        process_name: Optional[str] = None,
        window_title: Optional[str] = None,
        domain: Optional[str] = None
    ) -> bool:
        if domain and Config.is_llm_domain(f"https://{domain}"):
            return True
        if window_title:
            llm_keywords = ['chatgpt', 'copilot', 'claude', 'bard', 'gemini']
            title_lower = window_title.lower()
            if any(keyword in title_lower for keyword in llm_keywords):
                return True
        return False
